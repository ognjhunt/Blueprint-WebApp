// Private JSON-line pipe for the Python runner; stdout is not a worker log.
import {createHash, randomUUID} from 'node:crypto';
import {gzipSync, gunzipSync} from 'node:zlib';
import {createInterface} from 'node:readline';
import {pathToFileURL} from 'node:url';
import {livePublisher,publicationVerification,requirePublicationVerification,screenPayloadProblem} from './publisher.mjs';
import {verificationDigest} from './verification-digest.mjs';
import {contactResearchContext,claimContactResearch,finishContactResearchSafely} from './contact_research.mjs';

export const ROOT = 'blueprintDailyResearch/sites-first';
export const ADAPTIVE_TEST = 'adaptive-discovery-20261001';
export const COMMUNICATIONS_WORKER_LAP = 'blueprintCommunications/default/intakeState/workerLap';
const RELEASE_OWNER_PREFIX = 'research-release:';
const communicationsLapDrained = snapshot => {
  if (!snapshot.exists) return true;
  const lap = snapshot.data(), lease = lap?.lease;
  // An expired or malformed active lap still owns unfinished work. Only the
  // matching worker's explicit completion/zero-expiry record establishes drain.
  return lap?.schema_version === 'blueprint.communications-worker-lap.v1' && lap.phase === 'complete'
    && typeof lease?.owner === 'string' && /^communications-worker-lap:[a-zA-Z0-9-]{1,80}$/.test(lease.owner)
    && Number.isSafeInteger(lease.generation) && lease.generation >= 1
    && Number.isSafeInteger(lease.until) && lease.until === 0
    && Number.isSafeInteger(lap.startedAt) && Number.isSafeInteger(lap.renewedAt)
    && Number.isSafeInteger(lap.completedAt);
};
const MAX_BYTES = 8 * 1024 * 1024, CHUNK = 256 * 1024, LEASE_MS = 180000;
const TERMINAL = ['awaiting_review', 'reviewed', 'completed', 'failed', 'cancelled'];
const CLEANUP_BUCKET = 'blueprint-8c1ca.appspot.com';
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const canonicalValue = value => Array.isArray(value) ? value.map(canonicalValue) : value && typeof value === 'object'
  ? Object.fromEntries(Object.keys(value).sort().map(key => [key, canonicalValue(value[key])])) : value;
const valueHash = value => sha(JSON.stringify(canonicalValue(value)));
const pythonHash = value => sha(JSON.stringify(canonicalValue(value)).replace(/[^\x00-\x7F]/g,
  c=>'\\u'+c.charCodeAt(0).toString(16).padStart(4,'0')));
const same = (a, b) => JSON.stringify(Object.entries(a || {}).sort()) === JSON.stringify(Object.entries(b || {}).sort());
class Refusal extends Error {}
const refuse = code => {throw new Refusal(code);};
const dateOK = x => typeof x === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(x);
const sourceBinding=d=>valueHash({key:d.key,payload:d.payload,payload_json:d.payload_json,payload_digest:d.payload_digest});
const deliveryBinding=d=>valueHash({key:d.key,payload:d.payload,payload_json:d.payload_json,payload_digest:d.payload_digest,
  plan:d.plan||null,presentation:d.presentation||null});
const attemptState=(run,row,name)=>row.delivery[name].attempt_number
  ?run.publication_attempts?.[name]?.[row.delivery[name].attempt_number] || {}
  :{claimed:run.publication_claimed?.[name],batches:run.publication_batches?.[name] || {},
    delivery_binding:run.publication_delivery_bindings?.[name],rejection:run.publication_rejections?.[name]};
const claimUpdate=(run,row,name,digest,batches=null)=>{
  const d=row.delivery[name],binding=deliveryBinding(d);
  if(d.attempt_number) return {publication_attempts:{...run.publication_attempts,[name]:{
    ...run.publication_attempts?.[name],[d.attempt_number]:{...attemptState(run,row,name),claimed:digest,
      delivery_binding:binding,...(batches?{batches}:{})}}}};
  return {publication_claimed:{...run.publication_claimed,[name]:digest},
    publication_delivery_bindings:{...run.publication_delivery_bindings,[name]:binding},
    publication_source_bindings:{...run.publication_source_bindings,[name]:sourceBinding(d)},
    ...(batches?{publication_batches:{...run.publication_batches,[name]:batches}}:{})};
};
const fileOK = x => typeof x === 'string' && /^(?:\d{4}-\d{2}-\d{2}-(?:artifact|evidence|output|review|recovery|qa|qa-evidence|qa-input|publication-(?:input|evidence)|qa-correction-[12]-(?:input|artifact|evidence)|repair-[1-9]\d*-(?:input|artifact)|outreach-ready-shadow|inventory-[a-f0-9]{64}-\d+|exa-(?:http-[a-f0-9]{64}|[a-f0-9]{64}-(?:start(?:-http)?|read-[a-f0-9]{64}))|tool-[A-Za-z0-9_-]{1,200})|(?:crm|knowledge|refresh-policy))\.json$/.test(x);
// Owner-directed paid expansion allowance; mirrors tools/daily_research/allocation.py.
const PAID_DIRECTION='blueprint.research-paid-expansion-direction.v1', PAID_GRANT='blueprint.research-paid-expansion-grant.v1';
const PAID_PREFIX='operations/research/paid-expansion/', PAID_SOURCES=['exa','findall']; // Mirrors allocation.SOURCES.
const PAID_FIELDS=['approval_reference','approved_by','effective_from','expires_at','issued_at','per_run_limit_usd',
  'reason','schema_version','scope','sources','supersedes','version'];
const PAID_GRANT_FIELDS=['approval_reference','direction_sha256','direction_uri','frozen_at','grant_id','limit_micros',
  'per_start_max_micros','run_key','schema_version','source_commit','sources','state','valid_until','version'];
const hexOK=(x,n=64)=>typeof x==='string' && x.length===n && /^[a-f0-9]+$/.test(x);
const keysAre=(value,keys)=>!!value && typeof value==='object' && !Array.isArray(value)
  && JSON.stringify(Object.keys(value).sort())===JSON.stringify([...keys].sort());
const paidMicros=x=>{
  if(typeof x!=='string' || !/^[1-9]\d{0,2}(?:\.\d{2})?$/.test(x)) return null;
  const [whole,cents='0']=x.split('.'),value=Number(whole)*1000000+Number(cents)*10000;
  return value>=1000000 && value<=100000000?value:null;
};
const paidPerStart=limit=>Math.min(Math.max(Math.floor(limit/2),1000000),50000000);
// FindAll claims are the owner journal entries (parallel_findall_owner.SUBMISSIONS_FIELD). Each
// reserves its prepared request's whole maximum_cost_usd (mirrors allocation.findall_micros).
const FINDALL_FIELD='parallel_findall_submissions', FINDALL_PROFILE='parallel-findall-v1';
const findallMicros=x=>{
  if(typeof x!=='string' || !/^(?:0|[1-9]\d{0,2})(?:\.\d{1,2})?$/.test(x)) return null;
  const [whole,cents='']=x.split('.'),value=Number(whole)*1000000+Number(cents.padEnd(2,'0'))*10000;
  return value>0 && value<=100000000?value:null;
};
function findallClaims(row) {
  const entries=row[FINDALL_FIELD];
  if(entries===undefined || entries===null) return {};
  if(typeof entries!=='object' || Array.isArray(entries)) refuse('findall_claim_binding_invalid');
  const claims={};
  for(const [key,entry] of Object.entries(entries)) {
    const prepared=entry?.prepared,reserved=findallMicros(prepared?.maximum_cost_usd);
    if(!hexOK(key) || typeof entry?.operation_id!=='string' || sha(Buffer.from(entry.operation_id))!==key
        || !entry.operation_id.startsWith(`${row.run_key}:findall:`) || prepared?.operation_id!==entry.operation_id
        || prepared?.resource_class!=='parallel_findall' || typeof entry.allocation_binding_digest!=='string'
        || prepared.allocation_binding_digest!==entry.allocation_binding_digest || reserved===null
        || ![null,undefined].includes(entry.findall_id) && !/^findall_[A-Za-z0-9_-]+$/.test(entry.findall_id))
      refuse('findall_claim_binding_invalid');
    // The binding is immutable; state, receipt and the provider ID (once known) may advance.
    claims[key]={binding:valueHash({operation_id:entry.operation_id,
      allocation_binding_digest:entry.allocation_binding_digest,prepared}),
      reserved_micros:reserved,findall_id:entry.findall_id || null};
  }
  return claims;
}
const paidUri=hash=>`gs://${CLEANUP_BUCKET}/${PAID_PREFIX}${hash}/direction.json`;
// Whole UTC seconds on a real calendar day; Date.parse alone rolls 11-31 into 12-01.
const paidStamp=x=>{
  if(typeof x!=='string' || !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\+00:00$/.test(x)) return NaN;
  const ms=Date.parse(x);
  return Number.isFinite(ms) && new Date(ms).toISOString().slice(0,19)+'+00:00'===x?ms:NaN;
};
const paidText=x=>typeof x==='string' && /^[\x20-\x7e]{1,500}$/.test(x) && x.trim()!=='';
// Owner-pinned site universe export; mirrors tools/daily_research/site_universe.py.
const SU_PREFIX='operations/research/site-universe/', SU_NAME='backlog.v1.json.gz', SU_EXPORT='blueprint.site_universe.backlog.v1';
const SU_MAX_OBJECT=2*1024*1024, SU_MAX_RAW=6*1024*1024, SU_MAX_ROWS=5000;
const SU_PIN_FIELDS=['approval_reference','bytes','enabled','generation','rank_config_sha256','reoffer_after_days','sha256',
  'slice_size','snapshot_id','uri'];
const suUri=hash=>`gs://${CLEANUP_BUCKET}/${SU_PREFIX}${hash}/${SU_NAME}`;
const suGeneration=x=>typeof x==='string' && /^[1-9][0-9]{0,18}$/.test(x);
const suInt=(x,low,high)=>Number.isSafeInteger(x) && x>=low && x<=high;
const suCode=x=>typeof x==='string' && /^site_universe_[a-z_]{1,80}$/.test(x);
function suPinProblem(pin) {
  if(!keysAre(pin,SU_PIN_FIELDS) || pin.enabled!==true || !hexOK(pin.sha256) || pin.uri!==suUri(pin.sha256)
      || !suGeneration(pin.generation) || !suInt(pin.bytes,1,SU_MAX_OBJECT) || !hexOK(pin.snapshot_id)
      || !hexOK(pin.rank_config_sha256) || !suInt(pin.slice_size,5,30) || !suInt(pin.reoffer_after_days,1,365)
      || !paidText(pin.approval_reference) || /^PENDING/i.test(pin.approval_reference.trim())) return 'site_universe_pin_invalid';
  return null;
}
// Object reads have their own bound, inside firestore.py's 35 s pipe deadline, so a slow
// read refuses with a stable code and never marks the bridge broken.
async function suBounded(fn,ms) {
  let timer;
  const deadline=new Promise((_,reject)=>{timer=setTimeout(()=>reject(new Refusal('site_universe_object_unavailable')),ms);});
  try {return await Promise.race([fn(),deadline]);}
  catch(error) {throw error instanceof Refusal && suCode(error.message)?error:new Refusal('site_universe_object_unavailable');}
  finally {clearTimeout(timer);}
}
// Private qualified robot-team evidence: no provider or contact authority.
const TU_PREFIX='operations/research/team-universe/', TU_MAX_BYTES=4*1024*1024, TU_EXPORT='blueprint.team-evidence-export.v1';
const TU_PIN_FIELDS=['approval_reference','assessed_on','audit_sha256','bytes','enabled','generation','ranked_sha256','schema_version','scope_sha256','sha256','uri','version'];
const tuUri=hash=>`gs://${CLEANUP_BUCKET}/${TU_PREFIX}${hash}/evidence.v1.json`;
function tuPinProblem(pin) {
  if(!keysAre(pin,TU_PIN_FIELDS) || pin.schema_version!=='blueprint.team-evidence-pin.v1' || pin.enabled!==true
      || !['sha256','ranked_sha256','audit_sha256','scope_sha256'].every(k=>hexOK(pin[k]))
      || pin.uri!==tuUri(pin.sha256) || !suGeneration(pin.generation) || !suInt(pin.bytes,1,TU_MAX_BYTES)
      || !suInt(pin.version,1,1000000) || !dateOK(pin.assessed_on) || !paidText(pin.approval_reference)
      || /^PENDING/i.test(pin.approval_reference.trim())) return 'team_universe_pin_invalid';
  return null;
}
// Owner direction for outreach-ready hypotheses; mirrors tools/daily_research/outreach_ready.py.
// A new direction must name the rule this release implements (verification.OUTREACH_RULE_VERSION); a pinned
// direction of an earlier rule can still be braked, and a fresh set supersedes it.
const OR_DIRECTION='blueprint.outreach-ready-direction.v1', OR_RULE='blueprint.outreach-ready-rule.v1.2';
const OR_PREFIX='operations/research/outreach-ready/', OR_PATHS=['daily_qa','site_screen'], OR_MAX_OBJECT=16*1024;
const OR_FIELDS=['approval_reference','approved_by','binding','effective_from','expires_at','issued_at','reason',
  'rule_version','schema_version','scope','supersedes','version'];
const orUri=hash=>`gs://${CLEANUP_BUCKET}/${OR_PREFIX}${hash}/direction.json`;
const orCode=x=>typeof x==='string' && /^outreach_ready_[a-z_]{1,80}$/.test(x);
function orDirectionProblem(d,control) {
  if(!keysAre(d,OR_FIELDS) || d.schema_version!==OR_DIRECTION || d.rule_version!==OR_RULE) return 'outreach_ready_direction_invalid';
  const b=d.binding,s=d.scope,[issued,start,end]=['issued_at','effective_from','expires_at'].map(k=>paidStamp(d[k]));
  if(!keysAre(b,['agent_id','firestore_root','project_id','run_key_prefix','timezone'])
      || b.project_id!==control?.project_id || b.agent_id!==control?.agent_id || b.firestore_root!==ROOT
      || b.run_key_prefix!=='blueprint-researcher:' || b.timezone!=='America/Chicago') return 'outreach_ready_binding_mismatch';
  if(!keysAre(s,['label','max_rows_per_batch','paths','sends_authorized']) || s.label!=='hypothesis' || s.sends_authorized!==false
      || !Number.isSafeInteger(s.max_rows_per_batch) || s.max_rows_per_batch<1 || s.max_rows_per_batch>50
      || !Array.isArray(s.paths) || !s.paths.length || !s.paths.every((p,i)=>OR_PATHS.includes(p) && (i===0 || s.paths[i-1]<p)))
    return 'outreach_ready_scope_invalid';
  if(!Number.isSafeInteger(d.version) || d.version<1 || d.version>1000000 || (d.version===1)!==(d.supersedes===null)
      || d.supersedes!==null && !hexOK(d.supersedes) || !['approval_reference','approved_by','reason'].every(k=>paidText(d[k]))
      || /^PENDING/i.test(d.approval_reference.trim())
      || ![issued,start,end].every(Number.isFinite) || !(issued<=start && start<end) || end-issued>366*86400000)
    return 'outreach_ready_direction_invalid';
  return null;
}
async function orBounded(fn,ms) {
  let timer;
  const deadline=new Promise((_,reject)=>{timer=setTimeout(()=>reject(new Refusal('outreach_ready_object_unavailable')),ms);});
  try {return await Promise.race([fn(),deadline]);}
  catch(error) {throw error instanceof Refusal && orCode(error.message)?error:new Refusal('outreach_ready_object_unavailable');}
  finally {clearTimeout(timer);}
}
// Host-owned site-screen admission; mirrors tools/daily_research/screen_admission.py. The owner uploads a bundle
// create-only; admission_set pins exactly that generation; the worker plans, claims, writes and reads back its rows.
const SA_PREFIX='operations/research/screen-admission/', SA_NAME='bundle.json', SA_MAX_OBJECT=1024*1024, SA_MAX_RECORDS=50;
const SA_STATE='blueprint.site-screen-admission-state.v1', SA_WORK_ITEM='blueprint.site-screen-work-item.v1';
const SA_SNAPSHOT='blueprint.site-screen-admission-snapshot.v1';
const SA_PIN_FIELDS=['admission_id','approval_reference','bytes','direction_sha256','generation','records','uri'];
const SA_LABELS={published_person_email:'published person email',quoted_person_looked_up_email:'looked-up email, quoted person',
  provider_sourced_corroborated:'looked-up email, provider-sourced person, corroborated',
  provider_sourced_uncorroborated:'looked-up email, provider-sourced person, not corroborated',
  published_team_inbox:'published team inbox',published_general_inbox:'published general inbox'};
const SA_PERSON_ROUTES=['published_person_email','quoted_person_looked_up_email','provider_sourced_corroborated','provider_sourced_uncorroborated'];
const saUri=hash=>`gs://${CLEANUP_BUCKET}/${SA_PREFIX}${hash}/${SA_NAME}`;
const saCode=x=>typeof x==='string' && /^screen_admission_[a-z_]{1,80}$/.test(x);
function saPinProblem(value) {
  if(!keysAre(value,['current','enabled']) || typeof value.enabled!=='boolean') return 'screen_admission_pin_invalid';
  const c=value.current;
  if(!keysAre(c,SA_PIN_FIELDS) || !hexOK(c.admission_id) || !suGeneration(c.generation) || !suInt(c.bytes,1,SA_MAX_OBJECT)
      || c.uri!==saUri(c.admission_id) || !suInt(c.records,1,SA_MAX_RECORDS) || !hexOK(c.direction_sha256)
      || !paidText(c.approval_reference) || /^PENDING/i.test(c.approval_reference.trim())) return 'screen_admission_pin_invalid';
  return null;
}
async function saBounded(fn,ms) {
  let timer;
  const deadline=new Promise((_,reject)=>{timer=setTimeout(()=>reject(new Refusal('screen_admission_object_unavailable')),ms);});
  try {return await Promise.race([fn(),deadline]);}
  catch(error) {throw error instanceof Refusal && saCode(error.message)?error:new Refusal('screen_admission_object_unavailable');}
  finally {clearTimeout(timer);}
}
// Sheets columns E, F and H for one bundle recipient (screen_admission.contact_cells).
function saContactCells(recipient) {
  if(!recipient) return {name:'',details:'',source_url:''};
  const person=recipient.person || {};
  const suffix=person.site_responsibility?.route==='corporate_referral'
    ?'; corporate referral, target-site responsibility unknown':'';
  return {name:SA_PERSON_ROUTES.includes(recipient.route)?person.name || '':'',details:`${recipient.address} (${recipient.label}${suffix})`,
    source_url:recipient.published?.url || person.corroboration?.url || person.url || ''};
}
function paidDirectionProblem(d,control) {
  if(!keysAre(d,PAID_FIELDS) || d.schema_version!==PAID_DIRECTION) return 'paid_expansion_direction_invalid';
  if(paidMicros(d.per_run_limit_usd)===null) return 'paid_expansion_limit_invalid';
  const scope=d.scope,[issued,start,end]=['issued_at','effective_from','expires_at'].map(k=>paidStamp(d[k]));
  if(!keysAre(scope,['agent_id','firestore_root','project_id','run_key_prefix','timezone'])
      || scope.project_id!==control?.project_id || scope.agent_id!==control?.agent_id || scope.firestore_root!==ROOT
      || scope.run_key_prefix!=='blueprint-researcher:' || scope.timezone!=='America/Chicago') return 'paid_expansion_scope_mismatch';
  if(!Number.isSafeInteger(d.version) || d.version<1 || d.version>1000000 || (d.version===1)!==(d.supersedes===null)
      || d.supersedes!==null && !hexOK(d.supersedes) || !Array.isArray(d.sources) || !d.sources.length
      || !d.sources.every((s,i)=>PAID_SOURCES.includes(s) && (i===0 || d.sources[i-1]<s))
      || !['approval_reference','approved_by','reason'].every(k=>paidText(d[k])) || /^PENDING/i.test(d.approval_reference.trim())
      || ![issued,start,end].every(Number.isFinite) || !(issued<=start && start<end) || end-issued>366*86400000)
    return 'paid_expansion_direction_invalid';
  return null;
}

export class Store {
  constructor(db, clock = () => Date.now(), owner = randomUUID(), crmReader = null, publisher = null, learning = null,
    terminalCollectionReceipt = null, schedulerStopped = false, archiveBucket = null) {
    this.db = db; this.clock = clock; this.owner = owner; this.defaultOwner = owner; this.generation = null;
    this.control = db.doc(ROOT);
    this.crmReader = crmReader;
    this.publisher = publisher;
    this.learning = learning;
    this.terminalCollectionReceipt = terminalCollectionReceipt;
    this.schedulerStopped = schedulerStopped;
    this.archiveBucket = archiveBucket;
    this.siteUniverseReadMs = 20000; this.siteUniverseWriteMs = 30000;
    this.outreachReadyReadMs = 20000; this.outreachReadyWriteMs = 30000;
    this.screenAdmissionReadMs = 20000;
  }
  async transaction(fn) {
    return this.db.runTransaction(fn, {maxAttempts: 3});
  }
  fence(control) {
    const lease = control?.lease;
    if (!lease || lease.owner !== this.owner || lease.generation !== this.generation || lease.expires_at_ms <= this.clock())
      refuse('firestore_lease_lost');
  }
  async communicationsLapIdle() {
    return communicationsLapDrained(await this.db.doc(COMMUNICATIONS_WORKER_LAP).get());
  }
  async publicationFence(tx, control) {
    this.fence(control);
    if (!this.owner.startsWith(RELEASE_OWNER_PREFIX)) refuse('research_release_lease_required');
    if (!Number.isSafeInteger(control.lease.generation) || control.lease.generation < 1
        || !Number.isSafeInteger(control.lease.expires_at_ms)) refuse('firestore_lease_lost');
    // A direct absent-document read is part of the write transaction's read
    // set: a concurrent first lap claim conflicts, rather than escaping a query.
    if (!communicationsLapDrained(await tx.get(this.db.doc(COMMUNICATIONS_WORKER_LAP))))
      refuse('communications_worker_lap_active');
  }
  async acquire(scope = null) {
    if (scope !== null && scope !== 'research_release') refuse('firestore_lease_scope_invalid');
    const owner = scope === 'research_release' && !this.defaultOwner.startsWith(RELEASE_OWNER_PREFIX)
      ? RELEASE_OWNER_PREFIX + this.defaultOwner : this.defaultOwner;
    const generation = await this.transaction(async tx => {
      const snap = await tx.get(this.control);
      if (!snap.exists) refuse('firestore_control_missing');
      const control = snap.data(), lease = control.lease;
      if (owner.startsWith(RELEASE_OWNER_PREFIX) && (!Number.isSafeInteger(this.clock())
          || lease && (!Number.isSafeInteger(lease.expires_at_ms)
            || !Number.isSafeInteger(lease.generation) || lease.generation < 1
            || lease.generation >= Number.MAX_SAFE_INTEGER))) refuse('firestore_lease_invalid');
      if (lease && lease.expires_at_ms > this.clock()) refuse('runner_overlap');
      if (owner.startsWith(RELEASE_OWNER_PREFIX)
          && !communicationsLapDrained(await tx.get(this.db.doc(COMMUNICATIONS_WORKER_LAP))))
        refuse('communications_worker_lap_active');
      const generation = (lease?.generation || 0) + 1;
      if (owner.startsWith(RELEASE_OWNER_PREFIX) && !Number.isSafeInteger(this.clock() + LEASE_MS))
        refuse('firestore_lease_invalid');
      tx.set(this.control, {lease: {owner, generation, expires_at_ms: this.clock() + LEASE_MS}}, {merge: true});
      return generation;
    });
    this.owner = owner; this.generation = generation;
    return true;
  }
  async renew() {
    await this.transaction(async tx => {
      const control = (await tx.get(this.control)).data(); this.fence(control);
      if (this.owner.startsWith(RELEASE_OWNER_PREFIX)) await this.publicationFence(tx, control);
      tx.set(this.control, {lease: {...control.lease, expires_at_ms: this.clock() + LEASE_MS}}, {merge: true});
    });
    return true;
  }
  async release() {
    if (this.generation === null) return true;
    await this.transaction(async tx => {
      const control = (await tx.get(this.control)).data(), lease = control?.lease;
      // A late release may only clear this generation, never a successor lease.
      if (lease?.owner === this.owner && lease?.generation === this.generation)
        tx.set(this.control, {lease: {...lease, expires_at_ms: 0}}, {merge: true});
    });
    this.generation = null; return true;
  }
  async assertLease() {
    this.fence((await this.control.get()).data()); return true;
  }
  async blobPut(encoded) {
    const raw = Buffer.from(encoded, 'base64');
    if (raw.length > MAX_BYTES) refuse('firestore_blob_too_large');
    const hash = sha(raw), compressed = gzipSync(raw), count = Math.ceil(compressed.length / CHUNK);
    const ref = this.db.doc(`${ROOT}/blobs/${hash}`);
    await this.transaction(async tx => {
      const control = (await tx.get(this.control)).data(); this.fence(control);
      const prior = await tx.get(ref);
      if (prior.exists) {
        if (prior.data().bytes !== raw.length || prior.data().sha256 !== hash) refuse('firestore_blob_conflict');
        return;
      }
      for (let i = 0; i < count; i++) tx.set(this.db.doc(`${ref.path}/chunks/${i}`), {bytes: compressed.subarray(i * CHUNK, (i + 1) * CHUNK)});
      tx.set(ref, {sha256: hash, bytes: raw.length, chunks: count, codec: 'gzip', compressed_bytes: compressed.length});
    });
    return hash;
  }
  async blobGet(hash) {
    if (!/^[a-f0-9]{64}$/.test(hash)) refuse('firestore_blob_reference_invalid');
    const ref = this.db.doc(`${ROOT}/blobs/${hash}`), snap = await ref.get();
    if (!snap.exists) refuse('firestore_blob_missing');
    const meta = snap.data();
    if (meta.sha256 !== hash || meta.codec !== 'gzip' || !Number.isInteger(meta.bytes) || meta.bytes < 0 || meta.bytes > MAX_BYTES
        || !Number.isInteger(meta.chunks) || meta.chunks < 1 || meta.chunks > 33) refuse('firestore_blob_manifest_invalid');
    const chunks = await Promise.all(Array.from({length: meta.chunks}, (_, i) => this.db.doc(`${ref.path}/chunks/${i}`).get()));
    const compressed = Buffer.concat(chunks.map(c => {
      const b = c.data()?.bytes;
      if (!c.exists || !Buffer.isBuffer(b) || b.length > CHUNK) refuse('firestore_blob_chunk_invalid');
      return b;
    }));
    if (compressed.length !== meta.compressed_bytes) refuse('firestore_blob_length_mismatch');
    const raw = gunzipSync(compressed, {maxOutputLength: MAX_BYTES});
    if (raw.length !== meta.bytes || sha(raw) !== hash) refuse('firestore_blob_digest_mismatch');
    return raw.toString('base64');
  }
  async get(day) {
    if (!dateOK(day)) refuse('firestore_date_invalid');
    const snap = await this.db.doc(`${ROOT}/runs/${day}`).get();
    if (!snap.exists) return null;
    const row = JSON.parse(Buffer.from(await this.blobGet(snap.data().blob), 'base64').toString('utf8'));
    if (row.date !== day || row.run_key !== `blueprint-researcher:${day}` || !same(row.metadata, snap.data().metadata))
      refuse('firestore_row_binding_invalid');
    return row;
  }
  async blobReceipt(hash) {
    const bytes=await this.blobGet(hash),snap=await this.db.doc(`${ROOT}/blobs/${hash}`).get(),time=snap.createTime;
    if (!Number.isSafeInteger(time?.seconds) || !Number.isSafeInteger(time?.nanoseconds)
        || time.nanoseconds<0 || time.nanoseconds>=1000000000) refuse('firestore_blob_creation_time_unavailable');
    return {sha256:hash,bytes,created_at:{seconds:time.seconds,nanoseconds:time.nanoseconds}};
  }
  async rows() {
    const snaps = await this.db.collection(`${ROOT}/runs`).limit(10001).get();
    if (snaps.docs.length > 10000) refuse('firestore_history_limit');
    const result = [];
    for (const snap of snaps.docs) result.push(await this.get(snap.id));
    return result.sort((a, b) => a.date.localeCompare(b.date));
  }
  projectWorkItem(tx, row, hash) {
    const repair = row.state==='failed' && row.turn_status==='completed' && row.artifact_downloaded===true
      && !row.qa && !Object.keys(row.delivery || {}).length;
    if (row.packet || repair) tx.set(this.db.doc(`${ROOT}/workItems/${row.date}`), {
      date: row.date, run_key: row.run_key, row_blob: hash, packet_digest: row.packet_digest || null,
      owner: 'blueprint-research-qa-publication-agent',
      stage: repair ? (row.validation_repairs?.at(-1)?.state==='no_progress' ? 'validation_repair_blocked' : 'validation_repair_pending')
        : row.state === 'awaiting_review' ? 'agent_qa_pending' : row.state === 'reviewed' ? 'publication_pending' : row.state,
      qa_state: row.qa?.state || null, qa_error: row.qa?.error || null,
      observer_receipt_required: false, scope: 'research_only_no_outreach'
    });
  }
  async put(row,terminalWrite=null) {
    if (!dateOK(row?.date) || row.run_key !== `blueprint-researcher:${row.date}`) refuse('firestore_row_binding_invalid');
    if (row.search_provider === 'perplexity-fast-v1' && Buffer.byteLength(JSON.stringify(row)) > 7000000)
      refuse('research_tool_record_resource_ceiling');
    const hash = await this.blobPut(Buffer.from(JSON.stringify(row)).toString('base64'));
    const ref = this.db.doc(`${ROOT}/runs/${row.date}`);
    await this.transaction(async tx => {
      const control = (await tx.get(this.control)).data(); this.fence(control);
      const prior = await tx.get(ref);
      if(terminalWrite) {
        if(prior.data()?.blob!==terminalWrite.expected_blob) refuse('terminal_sheets_recovery_source_changed');
        this.terminalSheetsGate(control,row,terminalWrite.context);
      }
      if (!prior.exists && (row.state !== 'creating' || control.enabled !== true)) refuse('firestore_create_not_admitted');
      if (prior.exists && !same(prior.data().metadata, row.metadata)) refuse('firestore_intent_conflict');
      const teamDigest=row.team_universe===undefined?null:valueHash(row.team_universe);
      if(prior.exists && (prior.data().team_universe_digest ?? null)!==teamDigest) refuse('team_universe_intent_already_bound');
      if(row.team_universe?.state==='attached') {
        const evidence=row.team_universe,pin=evidence.pin;
        if(tuPinProblem(pin) || !prior.exists && valueHash(pin)!==valueHash(control.team_universe ?? null)) refuse('team_universe_current_pin_changed');
        const files=(row.create_payload?.environment?.files || []).filter(f=>f.path==='/workspace/inputs/blueprint-team-evidence.json');
        const raw=files.length===1 && typeof files[0].data==='string' ? Buffer.from(files[0].data,'base64') : null;
        if(!raw || raw.length>500000 || raw.length!==evidence.bytes || sha(raw)!==evidence.sha256
            || evidence.sha256!==row.metadata?.team_universe_input_digest) refuse('team_universe_frozen_binding_invalid');
        let frozen;try {frozen=JSON.parse(raw.toString('utf8'));} catch {refuse('team_universe_frozen_binding_invalid');}
        if(!keysAre(frozen,['schema_version','run_date','as_of','export_sha256','pin_version','manifest','teams','held_team_keys'])
            || frozen.schema_version!=='blueprint.team-evidence-input.v1' || frozen.run_date!==row.date
            || !dateOK(frozen.as_of) || !prior.exists && frozen.as_of!==new Date(this.clock()).toISOString().slice(0,10)
            || frozen.export_sha256!==pin.sha256 || frozen.pin_version!==pin.version
            || !Array.isArray(frozen.teams) || !Array.isArray(frozen.held_team_keys)
            || raw.toString('utf8')!==JSON.stringify(canonicalValue(frozen))) refuse('team_universe_frozen_binding_invalid');
        const original=Buffer.from(JSON.stringify(canonicalValue({schema_version:TU_EXPORT,manifest:frozen.manifest,teams:frozen.teams})));
        if(original.length!==pin.bytes || sha(original)!==pin.sha256) refuse('team_universe_frozen_binding_invalid');
        const asof=Date.parse(frozen.as_of+'T00:00:00Z');
        const held=frozen.teams.filter(team=>team.status==='capability_prospect' &&
          !(Number.isFinite(Date.parse(team.assessment?.as_of+'T00:00:00Z')) &&
            (asof-Date.parse(team.assessment.as_of+'T00:00:00Z'))/86400000>=0 &&
            (asof-Date.parse(team.assessment.as_of+'T00:00:00Z'))/86400000<=548)).map(team=>team.team_key);
        if(valueHash(held)!==valueHash(frozen.held_team_keys)) refuse('team_universe_frozen_binding_invalid');
      }
      if ((row.expansion_profile || null)!==(row.metadata?.expansion_profile || null)
          || row.expansion_profile && row.expansion_profile!=='exa-guarded-v1') refuse('research_expansion_profile_invalid');
      const exa=row.exa_expansion;
      if(exa && (row.expansion_profile!=='exa-guarded-v1' || exa.run_key!==row.run_key || exa.date!==row.date
          || typeof exa.intent_json!=='string' || sha(Buffer.from(exa.intent_json))!==exa.intent_sha256
          || valueHash(JSON.parse(exa.intent_json))!==valueHash(exa.intent))) refuse('expansion_intent_binding_changed');
      if(prior.data()?.exa_expansion_intent_digest && prior.data().exa_expansion_intent_digest!==exa?.intent_sha256)
        refuse('expansion_start_claim_already_consumed');
      if(prior.data()?.exa_expansion_run_id && prior.data().exa_expansion_run_id!==exa?.run_id)
        refuse('expansion_original_id_changed');
      if(prior.data()?.exa_expansion_terminal_receipt && !same(prior.data().exa_expansion_terminal_receipt,exa?.terminal_receipt))
        refuse('expansion_terminal_receipt_changed');
      const grant=row.paid_expansion_grant,grantDigest=grant===undefined || grant===null?null:valueHash(grant);
      // One frozen grant per row: bound at the durable intent, never replaced or added later.
      // A manifest an older bridge wrote cannot prove which grant the intent froze, so that
      // row stays unbound and admits no new paid claim.
      const priorGrant=prior.data()?.paid_expansion_grant_digest;
      const unbound=prior.exists && (priorGrant===undefined || prior.data().paid_expansion_grant_unbound===true);
      if(prior.exists && priorGrant!==undefined && priorGrant!==grantDigest) refuse('paid_expansion_grant_already_bound');
      if(!prior.exists && grant?.state==='granted') await this.paidGrantGate(tx,control,row,grant,true);
      // FindAll claims are append-only: a known claim keeps its exact binding and provider ID.
      // A manifest an older bridge rewrote adopts the row's claims and admits no new one.
      const findall=findallClaims(row),priorFindall=prior.data()?.findall_claims;
      const findallUnbound=prior.exists && (priorFindall===undefined || prior.data().findall_unbound===true);
      const knownFindall=priorFindall===undefined?(findallUnbound?findall:{}):priorFindall;
      for(const [key,claim] of Object.entries(knownFindall)) {
        if(!findall[key] || findall[key].binding!==claim.binding) refuse('findall_claim_already_consumed');
        if(claim.findall_id && findall[key].findall_id!==claim.findall_id) refuse('findall_original_id_changed');
      }
      if(Object.keys(findall).length && (row.findall_profile!==FINDALL_PROFILE || !hexOK(row.metadata?.findall_tools_digest)))
        refuse('findall_profile_invalid');
      const freshFindall=Object.keys(findall).filter(key=>!knownFindall[key]);
      // Exa and FindAll debit one combined allowance; an unknown cost holds its whole reservation.
      // The Exa reservation is the immutable intent's native budget on every write, so a
      // later rewrite of cap_micros cannot hide reserved spend from the combined check.
      const exaReserved=exa?Math.round(Number(exa.intent?.request?.budget?.maxCostDollars)*1000000):null;
      if(exa && (!Number.isSafeInteger(exaReserved) || exaReserved!==exa.cap_micros)) refuse('paid_expansion_claim_cap_mismatch');
      const reserved=[...(exa?[exaReserved]:[]),...Object.values(findall).map(claim=>claim.reserved_micros)];
      const overGrant=limit=>!reserved.every(v=>Number.isSafeInteger(v) && v>0)
        || reserved.reduce((a,b)=>a+b,0)>limit;
      if(exa && !prior.data()?.exa_expansion_intent_digest) {
        // A new paid claim debits the frozen grant; an unknown cost holds its whole cap.
        if(unbound || grant?.state!=='granted' || valueHash(exa.intent?.grant ?? null)!==grantDigest)
          refuse('paid_expansion_grant_required');
        const liveLimit=await this.paidGrantGate(tx,control,row,grant,false,'exa');
        const dollars=exa.intent?.request?.budget?.maxCostDollars;
        if(typeof dollars!=='number' || Math.round(dollars*1000000)!==exa.cap_micros) refuse('paid_expansion_claim_cap_mismatch');
        if(exa.cap_micros>paidPerStart(liveLimit) || overGrant(liveLimit)) refuse('paid_expansion_reservation_exceeds_grant');
      }
      if(freshFindall.length) {
        if(unbound || findallUnbound || grant?.state!=='granted') refuse('paid_expansion_grant_required');
        const liveLimit=await this.paidGrantGate(tx,control,row,grant,false,'findall');
        if(freshFindall.some(key=>findall[key].reserved_micros>paidPerStart(liveLimit)) || overGrant(liveLimit))
          refuse('paid_expansion_reservation_exceeds_grant');
      }
      const outreach=row.outreach_ready,outreachDigest=outreach===undefined || outreach===null?null:valueHash(outreach);
      // One frozen outreach-ready record per row, bound at the durable intent: never added, replaced or
      // dropped while bound. A shadow-mode row has no record and no field, exactly like an older manifest,
      // so a record whose manifest an older bridge rewrote (a rollback dropped the digest) cannot be
      // told apart from a record added later. Like paid_expansion_grant_unbound, that row is never
      // stranded: it binds the record it carries from then on, stays unbound, and publishes no hypothesis.
      const priorOutreach=prior.data()?.outreach_ready_digest;
      const outreachUnbound=prior.exists && (prior.data().outreach_ready_unbound===true
        || priorOutreach===undefined && outreachDigest!==null);
      if(prior.exists && priorOutreach!==undefined && priorOutreach!==outreachDigest) refuse('outreach_ready_already_bound');
      if(prior.data()?.mcp_profile && prior.data().mcp_profile!==row.mcp_profile)
        refuse('research_mcp_profile_changed');
      if(row.mcp_profile && (!['owner-readonly-mcp-v1','owner-delegated-research-mcp-v1'].includes(row.mcp_profile)
          || valueHash(row.mcp_binding)!==row.metadata?.mcp_binding_digest)) refuse('research_mcp_binding_changed');
      if(row.metadata?.mcp_vault_binding_digest && (!row.mcp_profile
          || valueHash(row.mcp_vault_binding)!==row.metadata.mcp_vault_binding_digest)) refuse('research_mcp_vault_binding_changed');
      const historyBinding=row.history_profile==='agent-history-v1'?valueHash(row.history_binding):null;
      if(row.history_profile && row.history_profile!=='agent-history-v1') refuse('company_history_profile_invalid');
      if(prior.exists && ((prior.data().history_profile || null)!==(row.history_profile || null)
          || (prior.data().history_binding_digest || null)!==historyBinding)) refuse('company_history_intent_conflict');
      if(!prior.exists && historyBinding && (row.history_binding?.enabled!==true
          || !control.learning || valueHash(control.learning)!==historyBinding)) refuse('company_history_authority_changed');
      const retryPhase = row.qa_retry_continuation ? sha(Buffer.from(JSON.stringify(row.qa_retry_continuation))) : null;
      const submissionBinding = row.qa?.submission_binding ? sha(Buffer.from(JSON.stringify(row.qa.submission_binding))) : null;
      const terminalCollection = row.qa?.terminal_collection_recovery ? sha(Buffer.from(JSON.stringify(row.qa.terminal_collection_recovery))) : null;
      if (prior.data()?.qa_retry_phase_digest && prior.data().qa_retry_phase_digest !== retryPhase)
        refuse('qa_retry_phase_already_bound');
      if (prior.data()?.qa_submission_binding_digest && prior.data().qa_submission_binding_digest !== submissionBinding)
        refuse('qa_submission_already_bound');
      if (prior.data()?.qa_terminal_collection_digest && prior.data().qa_terminal_collection_digest !== terminalCollection)
        refuse('qa_terminal_collection_already_bound');
      const retry = row.qa?.input_retries?.at(-1);
      const correction = row.qa?.corrections?.at(-1);
      const correctionBindings=Object.fromEntries((row.qa?.corrections || []).map(c=>[c.number, {
        request_digest:c.request_digest,deadline_ms:c.deadline_ms,idempotency_key:c.idempotency_key,
        authority_reference:c.authority_reference,previous_review:c.previous_review,baseline_turn_ids:c.baseline_turn_ids}]));
      if (Object.entries(prior.data()?.qa_correction_bindings || {}).some(([n,b])=>!same(b,correctionBindings[n])))
        refuse('qa_correction_already_bound');
      const publication=row.publication;
      const publicationBinding=publication?valueHash({profile:publication.profile,request_digest:publication.request_digest,
        session_id:publication.session_id,
        input_file:publication.input_file,idempotency_key:publication.idempotency_key,deadline_ms:publication.deadline_ms,
        authority_reference:publication.authority_reference,workflow_authority:publication.workflow_authority,
        baseline_turn_ids:publication.baseline_turn_ids}):null;
      if(prior.data()?.publication_input_binding && prior.data().publication_input_binding!==publicationBinding)
        refuse('publication_input_already_bound');
      if(prior.data()?.publication_turn_id && prior.data().publication_turn_id!==publication?.turn_id)
        refuse('publication_turn_already_bound');
      const cleanupBinding = row.cleanup ? pythonHash(row.cleanup.binding) : null;
      if (prior.data()?.cleanup_binding_digest && prior.data().cleanup_binding_digest !== cleanupBinding)
        refuse('cleanup_binding_already_bound');
      if (row.cleanup && (!prior.data()?.cleanup_archive || valueHash(prior.data().cleanup_archive)!==valueHash(row.cleanup.archive)))
        refuse('cleanup_archive_not_verified');
      if (prior.data()?.cleanup_delete_claimed && row.cleanup?.delete_claimed !== true)
        refuse('cleanup_claim_already_consumed');
      if (prior.data()?.cleanup_delete_confirmation
          && valueHash(prior.data().cleanup_delete_confirmation)!==valueHash(row.cleanup?.delete_confirmation))
        refuse('cleanup_confirmation_already_bound');
      for(const [name,binding] of Object.entries(prior.data()?.publication_delivery_bindings || {})) {
        // Receipts/state may advance; immutable request/plan/presentation evidence may not.
        const d=row.delivery?.[name];
        const active= d?.attempt_number?prior.data().publication_attempts?.[name]?.[d.attempt_number]:null;
        if(d?.attempt_number && (!active || sourceBinding(d)!==prior.data().publication_source_bindings?.[name]
            || (d.presentation?.decision_digest || null)!==active.presentation_digest))
          refuse('publication_attempt_not_admitted');
        const expected=active?active.delivery_binding:binding;
        if(expected && expected!==deliveryBinding(d)) refuse('publication_delivery_already_bound');
      }
      tx.set(ref, {date: row.date, blob: hash, metadata: row.metadata, state: row.state, cleanup_required: row.cleanup_required,
        expansion_profile:row.expansion_profile || null,
        exa_expansion_intent_digest:exa?.intent_sha256 || null,
        exa_expansion_run_id:exa?.run_id || null,
        exa_expansion_terminal_receipt:exa?.terminal_receipt || null,
        ...(row.team_universe===undefined?{}:{team_universe_digest:teamDigest}),paid_expansion_grant_digest:grantDigest,paid_expansion_grant_unbound:unbound,
        ...(outreachDigest?{outreach_ready_digest:outreachDigest}:{}),...(outreachUnbound?{outreach_ready_unbound:true}:{}),
        findall_claims:findall,findall_unbound:findallUnbound,
        ...(row.mcp_profile==='owner-delegated-research-mcp-v1'?{mcp_profile:row.mcp_profile}:{}),
        cleanup_binding_digest: cleanupBinding,
        cleanup_archive: prior.data()?.cleanup_archive || null,
        cleanup_delete_claimed: prior.data()?.cleanup_delete_claimed === true,
        cleanup_delete_confirmation:row.cleanup?.delete_confirmation || null,
        create_attempt_claimed: prior.exists && prior.data().create_attempt_claimed === true,
        session_id: row.session_id || null, turn_id: row.turn_id || null, environment_id: row.environment_id || null,
        qa_request_digest: row.qa?.request_digest || null, qa_state: row.qa?.state || null,
        qa_deadline_ms: row.qa?.deadline_ms || null,
        search_provider: row.search_provider || null, soft_target_usd: row.soft_target_usd ?? null,
        history_profile:row.history_profile || null,history_binding_digest:historyBinding,
        recurring_budget_authority_reference: row.recurring_budget_authority_reference || null,
        qa_request_claimed: prior.exists && prior.data().qa_request_claimed === true,
        qa_retry_phase_digest: retryPhase,
        qa_submission_binding_digest: submissionBinding,
        qa_terminal_collection_digest: terminalCollection,
        qa_retry_deadline_ms: row.qa_retry_continuation ? Date.parse(row.qa_retry_continuation.started_at) + 600000 : row.qa?.submission_binding?.deadline_ms || null,
        qa_retry_workflow_authority: row.qa_retry_continuation ? null : row.qa?.submission_binding?.authority_reference || null,
        qa_retry_number: retry?.number || null, qa_retry_key: retry?.idempotency_key || null,
        qa_retry_not_before_ms: retry ? Date.parse(retry.not_before) : null,
        qa_retry_prior_503: retry ? (row.qa.input_retries.length === 1 ? row.qa.input_error_receipt : row.qa.input_retries.at(-2)?.error_receipt) : null,
        qa_retry_claims: prior.exists ? prior.data().qa_retry_claims || {} : {},
        qa_correction_bindings:correctionBindings,
        qa_correction_number:correction?.number || null, qa_correction_state:correction?.state || null,
        qa_correction_claims:prior.exists ? prior.data().qa_correction_claims || {} : {},
        repair_request_digest: row.validation_repairs?.at(-1)?.request_digest || null,
        repair_deadline_ms: row.validation_repairs?.at(-1)?.deadline_ms || null,
        repair_number: row.validation_repairs?.at(-1)?.number || null,
        repair_state: row.validation_repairs?.at(-1)?.state || null,
        repair_claims: prior.exists ? prior.data().repair_claims || {} : {},
        publication_claimed: prior.exists ? prior.data().publication_claimed || {} : {},
        publication_batches: prior.exists ? prior.data().publication_batches || {} : {},
        publication_delivery_bindings:prior.exists ? prior.data().publication_delivery_bindings || {} : {},
        publication_source_bindings:prior.data()?.publication_source_bindings || {},
        publication_attempts:prior.data()?.publication_attempts || {},publication_rejections:prior.data()?.publication_rejections || {},
        publication_input_binding:publicationBinding,publication_input_claimed:prior.data()?.publication_input_claimed || false,
        publication_request_digest:publication?.request_digest || null,publication_deadline_ms:publication?.deadline_ms || null,
        publication_authority_reference:publication?.authority_reference || null,
        publication_state:publication?.state || null,publication_turn_id:publication?.turn_id || null});
      this.projectWorkItem(tx, row, hash);
    });
    await finishContactResearchSafely(this,row,hash);
    if(this.learning && ['awaiting_review','reviewed','completed','failed','cancelled'].includes(row.state)) {
      let observation;
      try {
        const control=(await this.control.get()).data();
        const result=await this.learning({op:'learning_after_run',day:row.date},control.learning);
        observation={row_blob:hash,status:['created','existing'].includes(result?.append)?'observed':'unavailable',
          append:result?.append || null,event_id:result?.event?.eventId || null,observed_at:new Date(this.clock()).toISOString()};
      } catch(error) {
        observation={row_blob:hash,status:'unavailable',code:/^[a-z_]{1,100}$/.test(error?.message || '')
          ?error.message:'research_learning_observation_unavailable',observed_at:new Date(this.clock()).toISOString()};
      }
      // Observation cannot undo or relabel the source commit. A later source
      // owns its own observation; do not overwrite it with this older result.
      try {await this.transaction(async tx=>{
        const control=(await tx.get(this.control)).data();this.fence(control);
        const current=await tx.get(ref);
        if(current.data()?.blob===hash) tx.set(this.db.doc(`${ROOT}/learningObservations/${hash}`),
          {...observation,run_ref:ref.path,source_row_blob:hash},{merge:true});
      });}catch { /* The committed research row remains authoritative. */ }
    }
    return true;
  }
  async filePut(name, encoded) {
    if (!fileOK(name)) refuse('firestore_file_invalid');
    const hash = await this.blobPut(encoded), ref = this.db.doc(`${ROOT}/files/${name}`);
    await this.transaction(async tx => {
      const control = (await tx.get(this.control)).data(); this.fence(control);
      const prior = await tx.get(ref);
      if ((name.endsWith('-artifact.json') || name.endsWith('-qa.json') || name.endsWith('-qa-input.json') || name.endsWith('-publication-input.json') || name.endsWith('-publication-evidence.json') || name.endsWith('-recovery.json') || /-inventory-|-exa-|-tool-|-repair-|-qa-correction-[12]-input/.test(name)) && prior.exists && prior.data().blob !== hash) refuse('artifact_identity_conflict');
      tx.set(ref, {blob: hash});
    });
    return true;
  }
  async fileGet(name) {
    if (!fileOK(name)) refuse('firestore_file_invalid');
    const snap = await this.db.doc(`${ROOT}/files/${name}`).get();
    if (!snap.exists) refuse('firestore_file_missing');
    return this.blobGet(snap.data().blob);
  }
  async snapshot(day) {
    if(!dateOK(day)) refuse('firestore_date_invalid');
    const manifest=(await this.db.doc(`${ROOT}/runs/${day}`).get());
    if(!manifest.exists) refuse('run_missing');
    const metadata=manifest.data(),source_row_json=Buffer.from(await this.blobGet(metadata.blob),'base64').toString('utf8');
    const row=JSON.parse(source_row_json);
    if(row.date!==day || row.run_key!==`blueprint-researcher:${day}` || !same(row.metadata,metadata.metadata))
      refuse('firestore_row_binding_invalid');
    for(const revision of row.validation_repairs || []) {
      if(revision.input_attempted===false && Object.hasOwn(metadata.repair_claims || {},revision.number))
        refuse('validation_repair_export_binding_mismatch');
    }
    const files = {}, missing = [];
    const unsubmittedInputs=new Set((row.validation_repairs || []).filter(r=>r.input_attempted===false)
      .map(r=>`repair-${r.number}-input`));
    for (const kind of ['artifact', 'evidence', 'output', 'review', ...(row.output_recovery ? ['recovery'] : []), ...(row.qa ? ['qa','qa-evidence'] : []),
      ...(row.qa?.input_file ? ['qa-input'] : []),
      ...(row.publication?.input_file ? ['publication-input'] : []),
      ...(row.publication?.evidence_file ? ['publication-evidence'] : []),
      ...(row.qa?.corrections?.length ? ['qa-original','qa-original-evidence'] : []),
      ...(row.qa?.corrections || []).flatMap(c=>[`qa-correction-${c.number}-input`,
        ...(c.artifact_file ? [`qa-correction-${c.number}-artifact`] : []),
        ...(c.evidence_file ? [`qa-correction-${c.number}-evidence`] : [])]),
      ...(row.validation_repairs || []).flatMap(r=>[`repair-${r.number}-input`, ...(r.artifact_file ? [`repair-${r.number}-artifact`] : [])]),
      ...Object.values(row.application_tool_calls || {}).filter(call=>call.result_file).map(call=>`tool-${call.request.call_id}`)]) {
      const names={'qa':row.qa?.artifact_file,'qa-evidence':row.qa?.evidence_file,
        'qa-original':row.qa?.corrections?.[0]?.previous_review?.artifact_file,
        'qa-original-evidence':row.qa?.corrections?.[0]?.previous_review?.evidence_file};
      try {files[kind] = await this.fileGet(names[kind] || `${day}-${kind}.json`);}
      catch (error) {
        if (!(error instanceof Refusal) || error.message !== 'firestore_file_missing') throw error;
        if (kind === 'artifact' && row.artifact_downloaded) refuse('artifact_not_downloaded_or_digest_mismatch');
        if (unsubmittedInputs.has(kind)) continue; // No input exists; retain any unexpected bytes if present.
        missing.push(kind);
      }
    }
    if (files.artifact && row.raw_output_digest !== sha(Buffer.from(files.artifact, 'base64')))
      refuse('artifact_not_downloaded_or_digest_mismatch');
    const inventory=row.packet?.discovery_inventory_manifest;
    if(inventory) {
      if(inventory.version!=='blueprint.discovery-inventory.v1' || inventory.complete_retention!==true
        || !Array.isArray(inventory.pages) || inventory.page_count!==inventory.pages.length
        || !/^[a-f0-9]{64}$/.test(inventory.source_output_digest)) refuse('discovery_inventory_manifest_invalid');
      const sources=[{artifact_file:`${day}-artifact.json`,artifact_digest:row.raw_output_digest},...(row.validation_repairs || [])];
      if(typeof inventory.source_artifact_file!=='string' || typeof inventory.source_artifact_sha256!=='string'
        || !sources.some(source=>source.artifact_file===inventory.source_artifact_file && source.artifact_digest===inventory.source_artifact_sha256))
        refuse('discovery_inventory_source_binding_invalid');
      const sourceRaw=Buffer.from(await this.fileGet(inventory.source_artifact_file),'base64');
      if(sha(sourceRaw)!==inventory.source_artifact_sha256) refuse('discovery_inventory_source_binding_invalid');
      let sourceText=sourceRaw.toString('utf8').replace(/^\uFEFF/,'');
      const fence=/^```(?:json)?[ \t]*\r?\n([\s\S]*)\r?\n```$/i.exec(sourceText.trim());
      if(fence) sourceText=fence[1];
      let sourceInventory;try {sourceInventory=JSON.parse(sourceText).discovery_inventory;}catch {refuse('discovery_inventory_source_binding_invalid');}
      if(!Array.isArray(sourceInventory) || verificationDigest(sourceInventory)!==inventory.records_digest)
        refuse('discovery_inventory_source_binding_invalid');
      let count=0;const retained=[];
      for(const [index,page] of inventory.pages.entries()) {
        if(page.index!==index || page.start!==count || !Number.isInteger(page.end) || page.end<=count
          || page.file!==`${day}-inventory-${inventory.source_output_digest}-${index}.json`) refuse('discovery_inventory_manifest_invalid');
        const encoded=await this.fileGet(page.file),raw=Buffer.from(encoded,'base64');
        // Verify size and digest before parsing untrusted page bytes.
        if(raw.length>100000 || raw.length!==page.bytes || sha(raw)!==page.sha256) refuse('discovery_inventory_page_binding_invalid');
        let value;try {value=JSON.parse(raw);}catch {refuse('discovery_inventory_page_binding_invalid');}
        if(value.version!==inventory.version
          || value.run_key!==row.run_key || value.source_output_digest!==inventory.source_output_digest
          || value.start!==page.start || value.end!==page.end || !Array.isArray(value.records)
          || value.records.length!==page.end-page.start) refuse('discovery_inventory_page_binding_invalid');
        files[page.file.slice(day.length+1,-5)]=encoded;retained.push(...value.records);count=page.end;
      }
      if(count!==inventory.record_count || verificationDigest(retained)!==inventory.records_digest) refuse('discovery_inventory_manifest_invalid');
    }
    const exaRefs=[...(row.exa_transport_receipts || []),
      ...['start_receipt','last_receipt','terminal_receipt'].map(key=>row.exa_expansion?.[key]).filter(Boolean)];
    for(const receipt of exaRefs) {
      if(typeof receipt.file!=='string' || !receipt.file.startsWith(`${day}-exa-`) || !receipt.file.endsWith('.json'))
        refuse('expansion_export_binding_invalid');
      const encoded=await this.fileGet(receipt.file),raw=Buffer.from(encoded,'base64');
      if(sha(raw)!==receipt.sha256 || raw.length!==receipt.bytes) refuse('expansion_receipt_digest_mismatch');
      files[receipt.file.slice(day.length+1,-5)]=encoded;
    }
    // FindAll created-run, owned-read and settlement receipts (findall.receipt_refs). Each snapshot is
    // ONE immutable file; a paged receipt also binds the page layout its reader slices from that file
    // (parallel_findall_owner.page_view). The retired multi-file parts format fails closed.
    const snapshotReceipts=[
      ...Object.values(row[FINDALL_FIELD] || {}).map(entry=>entry?.receipt).filter(receipt=>receipt!==undefined && receipt!==null),
      ...Object.values(row.parallel_findall_reads || {}),
      ...Object.values(row.parallel_findall_settlements || {}).flatMap(record=>record?.receipts || [])];
    const findallRefs=[
      ...Object.values(row[FINDALL_FIELD] || {}).filter(entry=>entry?.receipt_file)
        .map(entry=>({file:entry.receipt_file,sha256:entry.receipt_sha256})),
      ...Object.values(row.parallel_findall_reads || {}).map(read=>({file:read?.file,sha256:read?.sha256,bytes:read?.bytes})),
      ...Object.values(row.parallel_findall_settlements || {}).flatMap(record=>record?.receipts || [])];
    for(const receipt of findallRefs) {
      if(typeof receipt?.file!=='string' || !receipt.file.startsWith(`${day}-tool-findall-`) || !receipt.file.endsWith('.json'))
        refuse('findall_export_binding_invalid');
      const encoded=await this.fileGet(receipt.file),raw=Buffer.from(encoded,'base64');
      if(sha(raw)!==receipt.sha256 || receipt.bytes!==undefined && raw.length!==receipt.bytes) refuse('findall_receipt_digest_mismatch');
      files[receipt.file.slice(day.length+1,-5)]=encoded;
    }
    for(const receipt of snapshotReceipts) {
      const encoded=typeof receipt?.file==='string'?files[receipt.file.slice(day.length+1,-5)]:undefined;
      if(typeof encoded!=='string' || Object.hasOwn(receipt,'parts')) refuse('findall_snapshot_binding_invalid');
      const raw=Buffer.from(encoded,'base64');
      if(sha(raw)!==receipt.sha256 || raw.length!==receipt.bytes) refuse('findall_snapshot_binding_invalid');
      const paging=['schema_version','page_chars','page_count'].filter(key=>Object.hasOwn(receipt,key));
      if(paging.length) {
        // Code points, as Python slices them: every UTF-8 byte that is not a continuation byte.
        let chars=0;for(const byte of raw) if((byte&0xc0)!==0x80) chars++;
        if(paging.length!==3 || receipt.schema_version!=='blueprint.findall-snapshot.v2' || receipt.page_chars!==24000
            || !Number.isSafeInteger(receipt.page_count) || receipt.page_count<1
            || Math.ceil(chars/24000)!==receipt.page_count) refuse('findall_snapshot_binding_invalid');
      }
      try {JSON.parse(raw.toString('utf8'));} catch {refuse('findall_snapshot_binding_invalid');}
    }
    if (row.qa?.input_file) {
      const input = files['qa-input'] && Buffer.from(files['qa-input'], 'base64');
      if (row.qa.input_file !== `${day}-qa-input.json` || !input || input.at(-1) !== 10
        || sha(input.subarray(0, -1)) !== row.qa.request_digest)
        refuse('agent_qa_export_digest_mismatch');
    }
    for (const call of Object.values(row.application_tool_calls || {})) {
      if (call.result_file && (call.result_file !== `${day}-tool-${call.request.call_id}.json`
        || !files[`tool-${call.request.call_id}`] || call.result_sha256 !== sha(Buffer.from(files[`tool-${call.request.call_id}`], 'base64'))))
        refuse('research_tool_result_digest_mismatch');
    }
    const plans=Object.fromEntries(Object.entries(row.delivery || {}).filter(([,d])=>d.plan).map(([name,d])=>{
      const plan_json=JSON.stringify(canonicalValue(d.plan));return [name,{plan_json,plan_digest:sha(plan_json)}];
    }));
    const attempt_history={};
    for(const [name,attempts] of Object.entries(metadata.publication_attempts || {})) {
      attempt_history[name]={};
      for(const [number,attempt] of Object.entries(attempts)) {
        const history={...attempt};
        if(attempt.source_row_blob) history.source_row_json=Buffer.from(await this.blobGet(attempt.source_row_blob),'base64').toString('utf8');
        if(attempt.rejection?.response_blob) history.response_json=Buffer.from(await this.blobGet(attempt.rejection.response_blob),'base64').toString('utf8');
        attempt_history[name][number]=history;
      }
    }
    const activeClaims=Object.fromEntries(Object.keys(row.delivery || {}).filter(name=>attemptState(metadata,row,name).claimed)
      .map(name=>[name,attemptState(metadata,row,name).claimed]));
    const activeBatches=Object.fromEntries(Object.keys(row.delivery || {}).filter(name=>Object.keys(attemptState(metadata,row,name).batches || {}).length)
      .map(name=>[name,attemptState(metadata,row,name).batches]));
    const publicationProof={
        schema_version:'blueprint.research-publication-manifest.v1',date:row.date,run_key:row.run_key,
        source_row_blob:metadata.blob,source_row_json,plans,publication_claimed:activeClaims,
        publication_batches:activeBatches,...(Object.keys(attempt_history).length?{attempt_history}:{} )};
    const manifest_json=JSON.stringify(publicationProof);
    const publication=Object.keys(plans).length || Object.keys(metadata.publication_claimed || {}).length
      || Object.keys(metadata.publication_batches || {}).length ? {publication_manifest:{
        manifest_json,manifest_digest:sha(manifest_json)}} : {};
    const cleanup=metadata.cleanup_binding_digest ? {cleanup_manifest:{binding_digest:metadata.cleanup_binding_digest,
      archive:metadata.cleanup_archive,delete_claimed:metadata.cleanup_delete_claimed===true,
      delete_confirmation:metadata.cleanup_delete_confirmation || null}} : {};
    return {schema_version: 'blueprint.research-snapshot.v1', source_row_json, row, files, missing_files: missing,...publication,...cleanup};
  }
  async importRun(row) {
    if (!dateOK(row?.date) || row.run_key !== `blueprint-researcher:${row.date}` || !row.metadata)
      refuse('firestore_row_binding_invalid');
    const hash = await this.blobPut(Buffer.from(JSON.stringify(row)).toString('base64'));
    const ref = this.db.doc(`${ROOT}/runs/${row.date}`);
    return this.transaction(async tx => {
      const control = (await tx.get(this.control)).data(); this.fence(control);
      const prior = await tx.get(ref);
      if (control.enabled !== false) refuse('firestore_import_requires_disabled');
      if (prior.exists && prior.data().blob !== hash) refuse('firestore_import_date_conflict');
      // An identical import is archival reconciliation, never a reset of consumed claims.
      if(prior.exists) {this.projectWorkItem(tx,row,hash);return true;}
      const archived=row.state==='completed' && ['notion','sheets'].every(name=>
        row.delivery?.[name]?.state==='acknowledged' && row.delivery[name].receipt?.readback_verified===true);
      if((row.delivery?.notion?.plan?.protocol==='notion-paginated-v1' || row.publication
          || row.delivery?.notion?.attempt_number) && !archived)
        refuse('firestore_publication_restore_manifest_required');
      tx.set(ref, {date: row.date, blob: hash, metadata: row.metadata, state: row.state, cleanup_required: row.cleanup_required,
        create_attempt_claimed: true, session_id: row.session_id || null, turn_id: row.turn_id || null,
        expansion_profile:row.expansion_profile || null,
        exa_expansion_intent_digest:row.exa_expansion?.intent_sha256 || null,
        exa_expansion_run_id:row.exa_expansion?.run_id || null,
        exa_expansion_terminal_receipt:row.exa_expansion?.terminal_receipt || null,
        paid_expansion_grant_digest:row.paid_expansion_grant?valueHash(row.paid_expansion_grant):null,
        ...(row.outreach_ready?{outreach_ready_digest:valueHash(row.outreach_ready)}:{}),
        // An imported row keeps its claims and never admits a new one.
        findall_claims:findallClaims(row),findall_unbound:true,
        environment_id: row.environment_id || null});
      this.projectWorkItem(tx, row, hash);
      return true;
    });
  }
  async createCheck(day, metadata) {
    if (!dateOK(day)) refuse('firestore_date_invalid');
    return this.transaction(async tx => {
      const control = (await tx.get(this.control)).data(); this.fence(control);
      const snap = await tx.get(this.db.doc(`${ROOT}/runs/${day}`));
      if (control.enabled !== true || !snap.exists || snap.data().state !== 'creating' || snap.data().create_attempt_claimed
          || !same(snap.data().metadata, metadata)) refuse('firestore_create_not_admitted');
      this.budgetGate(control, snap.data());
      if(metadata.expansion_profile && (metadata.expansion_profile!=='exa-guarded-v1'
          || control.config?.expansion_profile!==metadata.expansion_profile
          || control.config?.mcp_profile==='owner-delegated-research-mcp-v1'))
        refuse('research_expansion_profile_changed');
      if(metadata.mcp_binding_digest && control.config?.mcp_profile!==(snap.data().mcp_profile || 'owner-readonly-mcp-v1'))
        refuse('research_mcp_profile_changed');
      if(snap.data().history_profile==='agent-history-v1') {
        if(control.config?.history_profile!=='agent-history-v1' || control.learning?.enabled!==true
            || snap.data().history_binding_digest!==valueHash(control.learning)
            || ['binding','businessScope'].some(key=>{
              const expiry=Date.parse(control.learning[key]?.expiresAt);
              return !Number.isFinite(expiry) || expiry<=this.clock();
            })) refuse('company_history_authority_changed_or_expired');
      } else if (control.learning?.enabled === true || metadata.learning_binding_digest) {
        if (control.learning?.enabled !== true || metadata.learning_binding_digest !== valueHash(control.learning)
            || ['binding','businessScope','learningGrant'].some(key => {
              const expiry = Date.parse(control.learning[key]?.expiresAt);
              return !Number.isFinite(expiry) || expiry <= this.clock();
            })) refuse('research_learning_create_scope_changed_or_expired');
      }
      await claimContactResearch(this,tx,day,metadata);
      tx.set(this.db.doc(`${ROOT}/runs/${day}`), {create_attempt_claimed: true}, {merge: true});
      return true;
    });
  }
  async summary() {
    const runs = this.db.collection(`${ROOT}/runs`);
    const [latest, unfinished, uncleaned] = await Promise.all([
      runs.orderBy('date', 'desc').limit(1).get(),
      runs.where('state', 'not-in', TERMINAL).limit(1).get(),
      runs.where('cleanup_required', '==', true).limit(1).get()
    ]);
    return {latest_date: latest.docs[0]?.id || null, unfinished: unfinished.docs.length > 0,
      cleanup_required: uncleaned.docs.length > 0};
  }
  cleanupGate(control,row,policy) {
    this.fence(control);
    if (this.schedulerStopped || control?.enabled!==true || control.config?.enabled!==true
        || policy?.enabled!==true || valueHash(control.cleanup_policy)!==valueHash(policy)
        || typeof policy.approval_reference!=='string' || !policy.approval_reference.trim()
        || policy.approval_reference.startsWith('PENDING') || !dateOK(policy.first_date)
        || policy.first_date<'2026-10-03' || row.date<policy.first_date
        || !Number.isFinite(Date.parse(policy.expires_at)) || Date.parse(policy.expires_at)<=this.clock()
        || policy.bucket!==CLEANUP_BUCKET || policy.project_id!==control.project_id
        || policy.project_id!==row.preflight?.project_id
        || policy.agent_id!==control.agent_id || policy.template_id!==control.template_id
        || row.create_payload?.agent_id!==policy.agent_id
        || row.create_payload?.environment?.environment_template_id!==policy.template_id
        || row.state!=='completed' || row.cleanup_required!==true || row.qa?.state!=='validated'
        || !['completed','agent_finished_without_complete_receipts'].includes(row.publication?.state)
        || !['completed','failed','cancelled'].includes(row.publication?.turn_status)
        || !['notion','sheets'].every(n=>row.delivery?.[n]?.state==='acknowledged'
          && row.delivery[n].receipt?.readback_verified===true
          && row.delivery[n].receipt.key===row.delivery[n].key
          && row.delivery[n].receipt.payload_digest===row.delivery[n].payload_digest))
      refuse('cleanup_standing_authority_not_admitted');
  }
  async cleanupAdmit(day,policy) {
    const control=(await this.control.get()).data(),row=await this.get(day);
    if (!row) refuse('run_missing');
    this.cleanupGate(control,row,policy);
    return true;
  }
  async cleanupStatus(day) {
    await this.assertLease();
    if (!dateOK(day)) refuse('firestore_date_invalid');
    const snap=await this.db.doc(`${ROOT}/runs/${day}`).get();
    return {delete_claimed:snap.data()?.cleanup_delete_claimed===true};
  }
  async archiveReadback(receipt) {
    if (!this.archiveBucket || receipt?.bucket!==CLEANUP_BUCKET || this.archiveBucket.name!==CLEANUP_BUCKET
        || !receipt.objects?.length) refuse('cleanup_archive_transport_unavailable');
    if (!receipt.objects.some(o=>o.name===receipt.prefix+'/source-row.json' && o.sha256===receipt.source_row_blob))
      refuse('cleanup_archive_readback_mismatch');
    for(let start=0;start<receipt.objects.length;start+=4) await Promise.all(receipt.objects.slice(start,start+4).map(async object=>{
      if (!object.name.startsWith(receipt.prefix+'/') || !/^[1-9][0-9]*$/.test(String(object.generation)))
        refuse('cleanup_archive_readback_mismatch');
      const file=this.archiveBucket.file(object.name,{generation:String(object.generation)});
      const [meta]=await file.getMetadata(),[raw]=await file.download();
      if(String(meta.generation)!==String(object.generation) || Number(meta.size)!==object.bytes
          || raw.length!==object.bytes || sha(raw)!==object.sha256) refuse('cleanup_archive_readback_mismatch');
    }));
    return true;
  }
  async cleanupArchive(request) {
    await this.cleanupAdmit(request.day,request.policy);
    const ref=this.db.doc(`${ROOT}/runs/${request.day}`),before=(await ref.get()).data();
    if(before.cleanup_archive) {
      await this.archiveReadback(before.cleanup_archive);
      return before.cleanup_archive;
    }
    if (!this.archiveBucket || this.archiveBucket.name!==CLEANUP_BUCKET) refuse('cleanup_archive_transport_unavailable');
    const row=await this.get(request.day),files=request.files;
    const required=['status.json',...(Object.values(row.delivery || {}).some(d=>d.plan)?['publication-manifest.json']:[]),
      'provider-session.json','provider-environment.json',
      'provider-turns.json','provider-items.json','provider-artifacts.json',`${request.day}-artifact.json`,
      `${request.day}-publication-evidence.json`];
    if (!files || !required.every(n=>typeof files[n]==='string')
        || valueHash(JSON.parse(Buffer.from(files['status.json'],'base64')))!==valueHash(row))
      refuse('cleanup_archive_incomplete');
    const names=[...Object.keys(files),'source-row.json'].sort(),objects=[];
    if(Object.hasOwn(files,'source-row.json')) refuse('cleanup_archive_source_changed');
    if(names.some(n=>!/^[-A-Za-z0-9_.]{1,200}$/.test(n))) refuse('cleanup_archive_name_invalid');
    const rawFiles=Object.fromEntries(Object.keys(files).map(n=>[n,Buffer.from(files[n],'base64')]));
    rawFiles['source-row.json']=Buffer.from(await this.blobGet(before.blob),'base64');
    const artifacts=JSON.parse(rawFiles['provider-artifacts.json']),session=JSON.parse(rawFiles['provider-session.json']);
    if(session.id!==row.session_id || session.environment?.id!==row.environment_id
        || valueHash(session.metadata)!==valueHash(row.metadata) || session.status!=='idle'
        || session.required_actions?.length || !Array.isArray(artifacts) || !artifacts.length
        || !artifacts.every(a=>typeof a.id==='string' && files[`provider-artifact-${sha(a.id)}.bin`]))
      refuse('cleanup_archive_incomplete');
    const secrets=value=>value && typeof value==='object' && Object.entries(value).some(([k,v])=>
      /^(?:access_token|refresh_token|api_key|private_key|client_secret|bearer_token)$/.test(k) && v
        || typeof v==='string' && /^Bearer\s/i.test(v) || secrets(v));
    if(secrets(session) || secrets(JSON.parse(rawFiles['provider-environment.json']))) refuse('cleanup_archive_credential_material');
    const manifest=Object.fromEntries(names.map(n=>[n,{sha256:sha(rawFiles[n]),bytes:rawFiles[n].length}]));
    const prefix=`operations/research/cleanup/${request.day}/${valueHash(manifest)}`;
    for(let start=0;start<names.length;start+=4) await Promise.all(names.slice(start,start+4).map(async n=>{
      const file=this.archiveBucket.file(`${prefix}/${n}`),raw=rawFiles[n];
      try {await file.save(raw,{resumable:false,preconditionOpts:{ifGenerationMatch:0},
        metadata:{contentType:'application/octet-stream',metadata:{sha256:sha(raw)}}});}
      catch(error) {if(Number(error.code)!==412) throw error;}
      const [meta]=await file.getMetadata();
      objects.push({name:file.name,sha256:sha(raw),bytes:raw.length,generation:String(meta.generation)});
    }));
    objects.sort((a,b)=>a.name.localeCompare(b.name));
    const receipt={bucket:CLEANUP_BUCKET,prefix,source_row_blob:before.blob,objects};
    await this.archiveReadback(receipt);
    await this.transaction(async tx=>{
      const control=(await tx.get(this.control)).data(),current=await tx.get(ref);
      this.cleanupGate(control,row,request.policy);
      if(current.data()?.blob!==before.blob || current.data()?.cleanup_archive) refuse('cleanup_archive_source_changed');
      tx.set(ref,{cleanup_archive:receipt},{merge:true});
    });
    return receipt;
  }
  async cleanupArchiveVerify(day,binding) {
    await this.assertLease();
    const run=(await this.db.doc(`${ROOT}/runs/${day}`).get()).data(),row=await this.get(day);
    if (!run || run.cleanup_binding_digest!==binding || pythonHash(row?.cleanup?.binding)!==binding
        || valueHash(row.cleanup.archive)!==valueHash(run.cleanup_archive)) refuse('cleanup_binding_changed');
    await this.archiveReadback(run.cleanup_archive);
    await this.assertLease();
    return true;
  }
  async cleanupClaim(day,binding,checkOnly=false) {
    const row=await this.get(day),ref=this.db.doc(`${ROOT}/runs/${day}`);
    return this.transaction(async tx=>{
      const control=(await tx.get(this.control)).data(),run=(await tx.get(ref)).data();
      this.cleanupGate(control,row,row?.cleanup?.binding?.policy);
      if(run?.cleanup_binding_digest!==binding || pythonHash(row?.cleanup?.binding)!==binding
          || valueHash(row.cleanup.archive)!==valueHash(run.cleanup_archive)
          || row.cleanup.binding.session_id!==run.session_id || row.cleanup.binding.environment_id!==run.environment_id)
        refuse('cleanup_binding_changed');
      if(checkOnly) {
        if(run.cleanup_delete_claimed!==true) refuse('cleanup_delete_not_claimed');
        return true;
      }
      if(run.cleanup_delete_claimed) return {submit:false};
      tx.set(ref,{cleanup_delete_claimed:true},{merge:true});
      tx.set(this.control,{cleanup_observation_required:true},{merge:true});
      return {submit:true};
    });
  }
  workflowGate(control, allowStopped = false) {
    const workflow=control?.workflow;
    if (!(control?.enabled === true || allowStopped && control?.enabled === false) || workflow?.enabled !== true
        || ['qa_authority_reference','publication_authority_reference'].some(k=>typeof workflow[k]!=='string'
          || !workflow[k].trim() || workflow[k].startsWith('PENDING'))) refuse('workflow_authority_missing');
  }
  budgetGate(control, row) {
    if (row.search_provider !== 'perplexity-fast-v1') return;
    const authority = row.recurring_budget_authority_reference, target = row.soft_target_usd;
    if (typeof authority !== 'string' || !authority.trim() || authority.trim().startsWith('PENDING')
        || typeof target !== 'number' || !Number.isFinite(target) || target <= 0)
      refuse('research_tool_budget_authority_not_pinned');
    if (control.config?.search_provider !== row.search_provider || control.config?.soft_target_usd !== target
        || control.config?.recurring_budget_authority_reference !== authority)
      refuse('research_tool_budget_authority_changed');
  }
  async paidGrantGate(tx,control,row,grant,atIntent,source=null) {
    // A granted record binds its audited owner direction, the live brake and the reviewed
    // release; at the durable intent it must also be frozen from the current direction.
    // Validate the live successor in this same transaction: it can tighten the source,
    // allowance or interval before a new reservation is durable. The worker repeats
    // the complete check immediately before POST, including the frozen run deadline.
    const limit=grant?.limit_micros;
    if(!keysAre(grant,PAID_GRANT_FIELDS) || grant.schema_version!==PAID_GRANT || grant.state!=='granted'
        || grant.run_key!==row.run_key || !hexOK(grant.direction_sha256) || source && !grant.sources?.includes(source)
        || grant.grant_id!==sha(JSON.stringify([grant.direction_sha256,row.run_key]))) refuse('paid_expansion_grant_not_admitted');
    const audit=(await tx.get(this.db.doc(`${ROOT}/paidExpansionDirections/${grant.direction_sha256}`))).data();
    if(!audit || audit.sha256!==grant.direction_sha256 || paidMicros(audit.direction?.per_run_limit_usd)!==limit
        || grant.per_start_max_micros!==paidPerStart(limit) || audit.version!==grant.version || audit.uri!==grant.direction_uri
        || !Array.isArray(grant.sources) || !grant.sources.every(s=>audit.direction.sources?.includes(s))
        || control?.paid_expansion?.enabled!==true || control.source_commit!==grant.source_commit
        || atIntent && control.paid_expansion.current?.sha256!==grant.direction_sha256) refuse('paid_expansion_grant_not_admitted');
    const current=control.paid_expansion.current;
    if(!keysAre(control.paid_expansion,['enabled','current']) || !keysAre(current,['sha256','version','uri','direction'])
        || paidDirectionProblem(current.direction,control) || valueHash(current.direction)!==current.sha256
        || current.version!==current.direction.version || current.uri!==paidUri(current.sha256)
        || source && !current.direction.sources.includes(source)
        || this.clock()<paidStamp(current.direction.effective_from) || this.clock()>=paidStamp(current.direction.expires_at))
      refuse('paid_expansion_grant_not_admitted');
    const liveAudit=(await tx.get(this.db.doc(`${ROOT}/paidExpansionDirections/${current.sha256}`))).data();
    if(!liveAudit || valueHash(liveAudit.direction)!==current.sha256 || liveAudit.sha256!==current.sha256
        || liveAudit.version!==current.version || liveAudit.uri!==current.uri) refuse('paid_expansion_grant_not_admitted');
    return Math.min(limit,paidMicros(current.direction.per_run_limit_usd));
  }
  async paidExpansionSet(expected,value) {
    // The only writer of control.paid_expansion: an owner direction compare-and-swap under
    // the lease. A new direction appends a create-only audit record; the same direction may
    // only be braked (enabled=false), and only a new owner direction re-enables expansion.
    if(!(expected===null || hexOK(expected)) || !keysAre(value,['current','enabled']) || typeof value.enabled!=='boolean'
        || !keysAre(value.current,['direction','sha256','uri','version'])) refuse('paid_expansion_request_invalid');
    const entry=value.current;
    return this.transaction(async tx=>{
      const control=(await tx.get(this.control)).data(); this.fence(control);
      const paid=control.paid_expansion,prior=paid?.current || null;
      if((prior?.sha256 ?? null)!==expected) refuse('paid_expansion_direction_conflict');
      if(expected!==null && entry.sha256===expected) {
        if(valueHash(entry)!==valueHash(prior)) refuse('paid_expansion_direction_conflict');
        if(value.enabled && paid.enabled!==true) refuse('paid_expansion_reenable_requires_new_direction');
        if(paid.enabled!==value.enabled) tx.set(this.control,{...control,paid_expansion:{enabled:value.enabled,current:prior}});
        return {enabled:value.enabled,sha256:entry.sha256,version:prior.version,audit:'existing'};
      }
      const problem=paidDirectionProblem(entry.direction,control);
      if(problem) refuse(problem);
      if(!hexOK(entry.sha256) || pythonHash(entry.direction)!==entry.sha256 || entry.version!==entry.direction.version
          || entry.uri!==paidUri(entry.sha256)) refuse('paid_expansion_direction_digest_mismatch');
      // The chain continues from control's current record or, when a rollback dropped it,
      // from the audit head, so one linear version chain survives.
      let parent=prior;
      if(!parent) {
        const audits=(await tx.get(this.db.collection(`${ROOT}/paidExpansionDirections`).limit(1001))).docs.map(s=>s.data());
        if(audits.length>1000) refuse('paid_expansion_audit_limit');
        parent=audits.reduce((head,record)=>!head || (record.version ?? 0)>(head.version ?? 0)?record:head,null);
      }
      if(!value.enabled || entry.direction.supersedes!==(parent?.sha256 ?? null)
          || entry.version!==(parent?(parent.version+1):1)) refuse('paid_expansion_direction_chain_invalid');
      const ref=this.db.doc(`${ROOT}/paidExpansionDirections/${entry.sha256}`);
      if((await tx.get(ref)).exists) refuse('paid_expansion_audit_conflict');
      tx.set(this.control,{...control,paid_expansion:{enabled:true,current:entry}});
      tx.set(ref,{sha256:entry.sha256,version:entry.version,uri:entry.uri,direction:entry.direction,
        recorded_at:new Date(this.clock()).toISOString()});
      return {enabled:true,sha256:entry.sha256,version:entry.version,audit:'created'};
    });
  }
  async paidExpansionAudit() {
    const snaps=await this.db.collection(`${ROOT}/paidExpansionDirections`).limit(1001).get();
    if(snaps.docs.length>1000) refuse('paid_expansion_audit_limit');
    return snaps.docs.map(snap=>snap.data()).sort((a,b)=>(a.version ?? 0)-(b.version ?? 0));
  }
  paidObject(hash) {
    if(!hexOK(hash)) refuse('paid_expansion_request_invalid');
    if(!this.archiveBucket || this.archiveBucket.name!==CLEANUP_BUCKET) refuse('paid_expansion_object_transport_unavailable');
    return this.archiveBucket.file(`${PAID_PREFIX}${hash}/direction.json`);
  }
  async paidExpansionObjectPut(hash,encoded) {
    // Content-addressed and create-only. The record grants nothing until paid_expansion_set,
    // so it needs no lease; the worker never reads it.
    const file=this.paidObject(hash),raw=Buffer.from(typeof encoded==='string'?encoded:'','base64');
    let direction;try {direction=JSON.parse(raw.toString('utf8'));} catch {refuse('paid_expansion_direction_invalid');}
    const problem=paidDirectionProblem(direction,(await this.control.get()).data());
    if(problem) refuse(problem);
    if(sha(raw)!==hash || pythonHash(direction)!==hash) refuse('paid_expansion_direction_digest_mismatch');
    try {await file.save(raw,{resumable:false,preconditionOpts:{ifGenerationMatch:0},
      metadata:{contentType:'application/json',metadata:{sha256:hash}}});}
    catch(error) {if(Number(error?.code)!==412) refuse('paid_expansion_object_write_unavailable');}
    return this.paidExpansionObjectGet(hash);
  }
  async paidExpansionObjectGet(hash) {
    const file=this.paidObject(hash);let meta,raw;
    try {[meta]=await file.getMetadata();[raw]=await file.download();}
    catch {refuse('paid_expansion_object_missing');}
    if(!Buffer.isBuffer(raw) || sha(raw)!==hash || Number(meta?.size)!==raw.length) refuse('paid_expansion_object_conflict');
    return {uri:paidUri(hash),sha256:hash,bytes:raw.toString('base64'),generation:String(meta.generation)};
  }
  teamUniverseFile(hash,generation=null) {
    if(!this.archiveBucket || this.archiveBucket.name!==CLEANUP_BUCKET) refuse('team_universe_object_unavailable');
    return this.archiveBucket.file(`${TU_PREFIX}${hash}/evidence.v1.json`,generation===null?undefined:{generation});
  }
  async teamUniverseObjectGet(hash,generation,size=null) {
    if(!hexOK(hash) || !suGeneration(generation) || !(size===null || suInt(size,1,TU_MAX_BYTES))) refuse('team_universe_pin_invalid');
    let timer;
    const read=async()=>{
      const file=this.teamUniverseFile(hash,generation);let meta,raw;
      try {[meta]=await file.getMetadata();} catch {refuse('team_universe_object_unavailable');}
      if(String(meta?.generation)!==generation) refuse('team_universe_object_generation_mismatch');
      const stored=Number(meta?.size);
      if(!suInt(stored,1,TU_MAX_BYTES)) refuse('team_universe_object_too_large');
      if(size!==null && size!==stored) refuse('team_universe_object_digest_mismatch');
      try {[raw]=await file.download();} catch {refuse('team_universe_object_unavailable');}
      if(!Buffer.isBuffer(raw) || raw.length!==stored || sha(raw)!==hash) refuse('team_universe_object_digest_mismatch');
      return {uri:tuUri(hash),sha256:hash,generation,size:raw.length,data:raw.toString('base64')};
    };
    try {return await Promise.race([read(),new Promise((_,reject)=>{timer=setTimeout(()=>reject(new Refusal('team_universe_object_unavailable')),20000);})]);}
    finally {clearTimeout(timer);}
  }
  async teamUniverseObjectPut(hash,encoded) {
    if(!hexOK(hash) || typeof encoded!=='string') refuse('team_universe_export_invalid');
    const raw=Buffer.from(encoded,'base64');let value;
    if(!raw.length || raw.length>TU_MAX_BYTES || sha(raw)!==hash) refuse('team_universe_object_digest_mismatch');
    try {value=JSON.parse(raw.toString('utf8'));} catch {refuse('team_universe_export_invalid');}
    if(value?.schema_version!==TU_EXPORT || value.manifest?.distribution!=='internal_only' || !Array.isArray(value.teams) || value.teams.length>10000)
      refuse('team_universe_export_invalid');
    let timer;
    const write=async()=>{
      const file=this.teamUniverseFile(hash);
      try {await file.save(raw,{resumable:false,preconditionOpts:{ifGenerationMatch:0},metadata:{contentType:'application/json',cacheControl:'private, no-store',metadata:{sha256:hash}}});}
      catch(error) {if(Number(error?.code)!==412) refuse('team_universe_object_unavailable');}
      let meta;try {[meta]=await file.getMetadata();} catch {refuse('team_universe_object_unavailable');}
      const read=await this.teamUniverseObjectGet(hash,String(meta?.generation),raw.length);
      return {uri:read.uri,sha256:hash,generation:read.generation,bytes:read.size};
    };
    try {return await Promise.race([write(),new Promise((_,reject)=>{timer=setTimeout(()=>reject(new Refusal('team_universe_object_unavailable')),30000);})]);}
    finally {clearTimeout(timer);}
  }

  async teamUniverseSnapshot() {
    // Read-only and pinned to one object generation. Daily intent freezes these bytes once.
    const control=(await this.control.get()).data(),pin=control?.team_universe;
    if(!pin || pin.enabled===false) return {state:'unavailable',code:'team_universe_not_pinned'};
    const problem=tuPinProblem(pin);if(problem) refuse(problem);
    const object=await this.teamUniverseObjectGet(pin.sha256,pin.generation,pin.bytes);
    let value;try {value=JSON.parse(Buffer.from(object.data,'base64').toString('utf8'));} catch {refuse('team_universe_export_invalid');}
    if(value?.schema_version!==TU_EXPORT || ['ranked_sha256','audit_sha256','scope_sha256','assessed_on'].some(k=>value.manifest?.[k]!==pin[k]))
      refuse('team_universe_export_binding_invalid');
    return {state:'available',pin,data:object.data};
  }
  async teamUniverseIdle() {
    const summary=await this.summary();
    if(summary.unfinished || await this.activeQA() || await this.workItem() || !await this.communicationsLapIdle())
      refuse('team_universe_active_research_qa_repair_or_publication');
    return {idle:true};
  }
  async teamUniverseSet(expected,value) {
    if(!(expected===null || hexOK(expected)) || !value || typeof value!=='object') refuse('team_universe_pin_invalid');
    // Caller also checks before acquiring; repeat under the exact existing fenced lease.
    await this.assertLease();await this.teamUniverseIdle();
    if(value.enabled!==false) {
      const problem=tuPinProblem(value);if(problem) refuse(problem);
      const object=await this.teamUniverseObjectGet(value.sha256,value.generation,value.bytes);
      let exportValue;try {exportValue=JSON.parse(Buffer.from(object.data,'base64').toString('utf8'));} catch {refuse('team_universe_export_invalid');}
      if(exportValue?.schema_version!==TU_EXPORT || ['ranked_sha256','audit_sha256','scope_sha256','assessed_on'].some(k=>exportValue.manifest?.[k]!==value[k]))
        refuse('team_universe_export_binding_invalid');
    }
    return this.transaction(async tx=>{
      const control=(await tx.get(this.control)).data();await this.publicationFence(tx,control);
      const prior=control.team_universe;
      if((prior?.sha256 ?? null)!==expected) refuse('team_universe_pin_conflict');
      if(value.enabled===false) {
        if(!prior || valueHash({...prior,enabled:false})!==valueHash(value)) refuse('team_universe_pin_invalid');
      } else {
        const problem=tuPinProblem(value);if(problem) refuse(problem);
        const history=await tx.get(this.db.collection(`${ROOT}/teamUniversePins`).limit(10001));
        if(history.docs.length>10000) refuse('team_universe_pin_history_limit');
        const version=history.docs.reduce((max,d)=>Math.max(max,d.data().version ?? 0),0);
        if(value.version!==Math.max(version,prior?.version ?? 0)+1) refuse('team_universe_pin_version_conflict');
        const ref=this.db.doc(`${ROOT}/teamUniversePins/${value.version}`);
        if((await tx.get(ref)).exists) refuse('team_universe_pin_conflict');
        tx.set(ref,{...value,recorded_at:new Date(this.clock()).toISOString()});
      }
      tx.set(this.control,{team_universe:value},{merge:true});
      return {enabled:value.enabled,sha256:value.sha256,version:value.version,generation:value.generation};
    });
  }
  suFile(hash,generation=null) {
    if(!this.archiveBucket || this.archiveBucket.name!==CLEANUP_BUCKET) refuse('site_universe_object_unavailable');
    return this.archiveBucket.file(`${SU_PREFIX}${hash}/${SU_NAME}`,generation===null?undefined:{generation});
  }
  async suRead(hash,generation,size) {
    // Exactly the pinned generation: generation, size and SHA-256 before any use. The size is
    // checked on metadata before download; only the owner command may omit it (size null).
    const missing=error=>Number(error?.code)===404?'site_universe_object_missing':'site_universe_object_unavailable';
    const file=this.suFile(hash,generation);let meta,raw;
    try {[meta]=await file.getMetadata();} catch(error) {refuse(missing(error));}
    if(String(meta?.generation)!==generation) refuse('site_universe_object_generation_mismatch');
    const stored=Number(meta?.size);
    if(!Number.isSafeInteger(stored) || stored>SU_MAX_OBJECT) refuse('site_universe_object_too_large');
    if(size!==null && stored!==size) refuse('site_universe_object_digest_mismatch');
    try {[raw]=await file.download();} catch(error) {refuse(missing(error));}
    if(!Buffer.isBuffer(raw) || raw.length>SU_MAX_OBJECT) refuse('site_universe_object_too_large');
    if(raw.length!==stored || sha(raw)!==hash) refuse('site_universe_object_digest_mismatch');
    return {uri:suUri(hash),sha256:hash,generation,size:raw.length,data:raw.toString('base64')};
  }
  async siteUniverseObjectGet(hash,generation,size) {
    if(!hexOK(hash) || !suGeneration(generation) || !(size===null || suInt(size,1,SU_MAX_OBJECT)))
      refuse('site_universe_pin_invalid');
    return suBounded(()=>this.suRead(hash,generation,size),this.siteUniverseReadMs);
  }
  async siteUniverseObjectPut(hash,encoded) {
    // Content-addressed and create-only. An export grants nothing until site_universe_set pins
    // it, so it needs no lease. The Python loader is the full validator; this keeps the bounds.
    if(!hexOK(hash) || typeof encoded!=='string') refuse('site_universe_pin_invalid');
    const raw=Buffer.from(encoded,'base64');
    if(raw.length>SU_MAX_OBJECT) refuse('site_universe_object_too_large');
    if(!raw.length || sha(raw)!==hash) refuse('site_universe_object_digest_mismatch');
    let document;
    try {document=JSON.parse(gunzipSync(raw,{maxOutputLength:SU_MAX_RAW}).toString('utf8'));} catch {refuse('site_universe_export_invalid');}
    if(document?.schema_version!==SU_EXPORT || document.manifest?.distribution!=='internal_only'
        || !Array.isArray(document.rows) || !document.rows.length || document.rows.length>SU_MAX_ROWS)
      refuse('site_universe_export_invalid');
    return suBounded(async()=>{
      const file=this.suFile(hash);
      try {await file.save(raw,{resumable:false,preconditionOpts:{ifGenerationMatch:0},
        metadata:{contentType:'application/gzip',metadata:{sha256:hash}}});}
      catch(error) {if(Number(error?.code)!==412) refuse('site_universe_object_unavailable');}
      let meta;try {[meta]=await file.getMetadata();} catch {refuse('site_universe_object_unavailable');}
      const stored=await this.suRead(hash,String(meta?.generation),raw.length);
      return {uri:stored.uri,sha256:hash,generation:stored.generation,size:stored.size};
    },this.siteUniverseWriteMs);
  }
  async siteUniverseSet(expected,value) {
    // The only writer of control.site_universe: a compare-and-swap under the fenced lease. A pin
    // is complete and valid; disable keeps the current pin exactly, with enabled=false.
    if(!(expected===null || hexOK(expected)) || !value || typeof value!=='object' || Array.isArray(value))
      refuse('site_universe_pin_invalid');
    return this.transaction(async tx=>{
      const control=(await tx.get(this.control)).data(); this.fence(control);
      const prior=control.site_universe ?? null;
      if((prior?.sha256 ?? null)!==expected) refuse('site_universe_control_conflict');
      if(value.enabled===false) {
        if(!prior || valueHash({...prior,enabled:false})!==valueHash(value)) refuse('site_universe_pin_invalid');
      } else {
        const problem=suPinProblem(value);
        if(problem) refuse(problem);
      }
      tx.set(this.control,{...control,site_universe:value});
      return {enabled:value.enabled,sha256:value.sha256 ?? null,generation:value.generation ?? null};
    });
  }
  orFile(hash,generation=null) {
    if(!this.archiveBucket || this.archiveBucket.name!==CLEANUP_BUCKET) refuse('outreach_ready_object_unavailable');
    return this.archiveBucket.file(`${OR_PREFIX}${hash}/direction.json`,generation===null?undefined:{generation});
  }
  async orRead(hash,generation) {
    // Exactly the pinned generation: generation, size and SHA-256 before any use.
    const missing=error=>Number(error?.code)===404?'outreach_ready_object_missing':'outreach_ready_object_unavailable';
    const file=this.orFile(hash,generation);let meta,raw;
    try {[meta]=await file.getMetadata();} catch(error) {refuse(missing(error));}
    if(String(meta?.generation)!==generation) refuse('outreach_ready_object_generation_mismatch');
    const stored=Number(meta?.size);
    if(!Number.isSafeInteger(stored) || stored<1 || stored>OR_MAX_OBJECT) refuse('outreach_ready_object_too_large');
    try {[raw]=await file.download();} catch(error) {refuse(missing(error));}
    if(!Buffer.isBuffer(raw) || raw.length!==stored || sha(raw)!==hash) refuse('outreach_ready_object_digest_mismatch');
    return {uri:orUri(hash),sha256:hash,generation,bytes:raw.toString('base64')};
  }
  async outreachReadyObjectGet(hash,generation) {
    if(!hexOK(hash) || !suGeneration(generation)) refuse('outreach_ready_pin_invalid');
    return orBounded(()=>this.orRead(hash,generation),this.outreachReadyReadMs);
  }
  async outreachReadyObjectPut(hash,encoded) {
    // Content-addressed and create-only. A direction grants nothing until outreach_ready_set
    // pins its generation, so it needs no lease; the worker never reads it.
    if(!hexOK(hash) || typeof encoded!=='string') refuse('outreach_ready_pin_invalid');
    const raw=Buffer.from(encoded,'base64');
    if(!raw.length || raw.length>OR_MAX_OBJECT) refuse('outreach_ready_object_too_large');
    let direction;try {direction=JSON.parse(raw.toString('utf8'));} catch {refuse('outreach_ready_direction_invalid');}
    const problem=orDirectionProblem(direction,(await this.control.get()).data());
    if(problem) refuse(problem);
    if(sha(raw)!==hash || pythonHash(direction)!==hash) refuse('outreach_ready_direction_digest_mismatch');
    return orBounded(async()=>{
      const file=this.orFile(hash);
      try {await file.save(raw,{resumable:false,preconditionOpts:{ifGenerationMatch:0},
        metadata:{contentType:'application/json',metadata:{sha256:hash}}});}
      catch(error) {if(Number(error?.code)!==412) refuse('outreach_ready_object_unavailable');}
      let meta;try {[meta]=await file.getMetadata();} catch {refuse('outreach_ready_object_unavailable');}
      const stored=await this.orRead(hash,String(meta?.generation));
      return {uri:stored.uri,sha256:hash,generation:stored.generation,size:raw.length};
    },this.outreachReadyWriteMs);
  }
  async outreachReadySet(expected,value) {
    // The only writer of control.outreach_ready: a compare-and-swap under the fenced lease. A new
    // direction must be exactly the bytes of its pinned, immutable generation and continue the
    // version chain; the same direction may only be braked (enabled=false), and only a new owner
    // direction re-enables it. Live admission rereads this pin, so the brake applies at once.
    if(!(expected===null || hexOK(expected)) || !keysAre(value,['current','enabled']) || typeof value.enabled!=='boolean'
        || !keysAre(value.current,['direction','generation','sha256','uri','version'])) refuse('outreach_ready_request_invalid');
    const entry=value.current,fresh=expected===null || entry.sha256!==expected;
    if(fresh) {
      const problem=orDirectionProblem(entry.direction,(await this.control.get()).data());
      if(problem) refuse(problem);
      if(!hexOK(entry.sha256) || pythonHash(entry.direction)!==entry.sha256 || entry.version!==entry.direction.version
          || entry.uri!==orUri(entry.sha256) || !suGeneration(entry.generation)) refuse('outreach_ready_direction_digest_mismatch');
      await this.outreachReadyObjectGet(entry.sha256,entry.generation);  // Its SHA-256 is the direction's canonical bytes.
    }
    return this.transaction(async tx=>{
      const control=(await tx.get(this.control)).data(); this.fence(control);
      const pin=control.outreach_ready,prior=pin?.current || null;
      if((prior?.sha256 ?? null)!==expected) refuse('outreach_ready_direction_conflict');
      if(!fresh) {
        if(valueHash(entry)!==valueHash(prior)) refuse('outreach_ready_direction_conflict');
        if(value.enabled && pin.enabled!==true) refuse('outreach_ready_reenable_requires_new_direction');
        if(pin.enabled!==value.enabled) tx.set(this.control,{...control,outreach_ready:{enabled:value.enabled,current:prior}});
        return {enabled:value.enabled,sha256:prior.sha256,generation:prior.generation,version:prior.version};
      }
      const problem=orDirectionProblem(entry.direction,control);
      if(problem) refuse(problem);
      if(prior && (!hexOK(prior.sha256) || !Number.isSafeInteger(prior.version) || prior.version<1))
        refuse('outreach_ready_current_unverified');
      if(!value.enabled || entry.direction.supersedes!==(prior?.sha256 ?? null) || entry.version!==(prior?prior.version+1:1))
        refuse('outreach_ready_direction_chain_invalid');
      tx.set(this.control,{...control,outreach_ready:{enabled:true,current:entry}});
      return {enabled:true,sha256:entry.sha256,generation:entry.generation,version:entry.version};
    });
  }
  // --- host-owned site-screen admission (screen_admission.py) ---------------------------------------------------
  saFile(hash,generation=null) {
    if(!this.archiveBucket || this.archiveBucket.name!==CLEANUP_BUCKET) refuse('screen_admission_object_unavailable');
    return this.archiveBucket.file(`${SA_PREFIX}${hash}/${SA_NAME}`,generation===null?undefined:{generation});
  }
  async saRead(hash,generation,size) {
    // Exactly the pinned generation: generation, size and SHA-256 before any use.
    const missing=error=>Number(error?.code)===404?'screen_admission_object_missing':'screen_admission_object_unavailable';
    const file=this.saFile(hash,generation);let meta,raw;
    try {[meta]=await file.getMetadata();} catch(error) {refuse(missing(error));}
    if(String(meta?.generation)!==generation) refuse('screen_admission_object_generation_mismatch');
    const stored=Number(meta?.size);
    if(!Number.isSafeInteger(stored) || stored<1 || stored>SA_MAX_OBJECT) refuse('screen_admission_object_too_large');
    if(size!==null && stored!==size) refuse('screen_admission_object_digest_mismatch');
    try {[raw]=await file.download();} catch(error) {refuse(missing(error));}
    if(!Buffer.isBuffer(raw) || raw.length!==stored || sha(raw)!==hash) refuse('screen_admission_object_digest_mismatch');
    return {uri:saUri(hash),sha256:hash,generation,size:raw.length,data:raw.toString('base64')};
  }
  async screenAdmissionObjectGet(hash,generation,size) {
    if(!hexOK(hash) || !suGeneration(generation) || !(size===null || suInt(size,1,SA_MAX_OBJECT)))
      refuse('screen_admission_pin_invalid');
    return saBounded(()=>this.saRead(hash,generation,size),this.screenAdmissionReadMs);
  }
  saRef(id) {return this.db.doc(`${ROOT}/screenAdmissions/${id}`);}
  saSummary(meta) {
    if(!meta) return null;
    return {state:meta.claimed && meta.state!=='acknowledged'?'claimed':meta.state,claimed:!!meta.claimed,
      rows:meta.rows ?? null,duplicates:meta.duplicates ?? null};
  }
  async screenAdmissionGet(id) {
    if(!hexOK(id)) refuse('screen_admission_id_invalid');
    const snap=await this.saRef(id).get();
    return snap.exists?this.saSummary(snap.data()):null;
  }
  async screenAdmissionHistory() {
    // Earlier admissions for the worker's dedupe: only acknowledged ones wrote rows; any other row is in the CRM itself.
    const snaps=await this.db.collection(`${ROOT}/screenAdmissions`).limit(1001).get();
    if(snaps.docs.length>1000) refuse('screen_admission_history_limit');
    return snaps.docs.filter(s=>s.data().state==='acknowledged').map(s=>({admission_id:s.id,state:'acknowledged',
      site_keys:s.data().site_keys || [],identities:s.data().identities || []}));
  }
  async screenAdmissionSet(expected,value,supersedeUncertain=false) {
    // The only writer of control.screen_admission: a compare-and-swap under the fenced lease. A new pin names exactly
    // an uploaded generation; the same pin may only be braked or re-enabled. A pin whose claimed write has no readback
    // is replaced only with the owner's explicit supersede flag.
    if(!(expected===null || hexOK(expected)) || typeof supersedeUncertain!=='boolean') refuse('screen_admission_request_invalid');
    const problem=saPinProblem(value);
    if(problem) refuse(problem);
    const c=value.current,fresh=expected===null || c.admission_id!==expected;
    if(fresh) {
      if(!value.enabled) refuse('screen_admission_pin_invalid');
      await this.screenAdmissionObjectGet(c.admission_id,c.generation,c.bytes);
    }
    return this.transaction(async tx=>{
      const control=(await tx.get(this.control)).data(); await this.publicationFence(tx,control);
      const prior=control.screen_admission ?? null;
      if((prior?.current?.admission_id ?? null)!==expected) refuse('screen_admission_control_conflict');
      const meta=prior && fresh?(await tx.get(this.saRef(prior.current.admission_id))).data():null;
      if(!fresh && valueHash(prior.current)!==valueHash(c)) refuse('screen_admission_control_conflict');
      if(meta?.claimed && meta.state!=='acknowledged' && !supersedeUncertain) refuse('screen_admission_current_write_uncertain');
      tx.set(this.control,{...control,screen_admission:value});
      return {enabled:value.enabled,admission_id:c.admission_id,generation:c.generation};
    });
  }
  saDirectionRecord(control) {
    const entry=control.outreach_ready.current,d=entry.direction,s=d.scope;
    return {sha256:entry.sha256,generation:entry.generation,uri:entry.uri,version:entry.version,rule_version:d.rule_version,
      paths:[...s.paths],label:s.label,max_rows_per_batch:s.max_rows_per_batch,sends_authorized:false,
      effective_from:d.effective_from,expires_at:d.expires_at,approval_reference:d.approval_reference};
  }
  screenGate(control,request) {
    // The live pin and the live owner direction, rechecked before every plan, claim and write: the brake on either
    // stops the admission at once (a claimed write is only read back).
    const pin=control?.screen_admission,c=pin?.current;
    if(saPinProblem(pin) || pin.enabled!==true || c.admission_id!==request.admission_id || c.generation!==request.generation)
      refuse('screen_admission_not_pinned');
    const or=control.outreach_ready,entry=or?.current,d=entry?.direction;
    if(or?.enabled!==true || !d || orDirectionProblem(d,control) || pythonHash(d)!==entry.sha256 || entry.sha256!==c.direction_sha256
        || valueHash(this.saDirectionRecord(control))!==valueHash(request.direction ?? null)) refuse('screen_admission_direction_changed');
    if(!d.scope.paths.includes('site_screen')) refuse('screen_admission_path_not_directed');
    const now=this.clock();
    if(!(paidStamp(d.effective_from)<=now && now<paidStamp(d.expires_at))) refuse('screen_admission_direction_expired');
  }
  saBundleBinding(bundle,payload) {
    // Every row the worker asks for comes from the pinned bundle: each result is written or named a duplicate, and each
    // entry repeats its result's digest, candidate, question and recipient cells exactly.
    const results=Array.isArray(bundle?.results)?bundle.results:[],named=new Map(results.map(r=>[r?.site_key,r]));
    const listed=[...payload.entries.map(e=>e.site_key),...payload.duplicates.map(d=>d.site_key)];
    if(results.length!==listed.length || new Set(listed).size!==listed.length || listed.some(key=>!named.has(key)))
      refuse('screen_admission_payload_binding_invalid');
    for(const entry of payload.entries) {
      const r=named.get(entry.site_key),c=r.candidate || {};
      if(entry.result_digest!==r.result_digest || entry.question!==r.hypothesis?.question
          || ['organization','site','location','task','task_url','checked_on'].some(key=>entry[key]!==c[key])
          || valueHash(entry.contact)!==valueHash(saContactCells(r.recipient))) refuse('screen_admission_payload_binding_invalid');
    }
  }
  async saPut(ref,state,status,expected) {
    const hash=await this.blobPut(Buffer.from(JSON.stringify(state)).toString('base64'));
    const fields={admission_id:state.admission_id,blob:hash,state:status,claimed:null,
      site_keys:state.payload.entries.map(e=>e.site_key),identities:state.payload.entries.map(e=>e.identity),
      rows:state.plan.sheet_rows.length,duplicates:state.payload.duplicates.length,updated_at:new Date(this.clock()).toISOString()};
    await this.transaction(async tx=>{
      const control=(await tx.get(this.control)).data(); await this.publicationFence(tx,control);
      const prior=(await tx.get(ref)).data();
      if((prior?.blob ?? null)!==expected || prior?.claimed) refuse('screen_admission_state_changed');
      tx.set(ref,fields);
    });
    return fields;
  }
  async screenAdmissionPublish(request) {
    await this.assertLease();
    await this.transaction(async tx=>{
      const control=(await tx.get(this.control)).data();await this.publicationFence(tx,control);
    });
    const id=request?.admission_id,generation=request?.generation;
    if(!hexOK(id) || !suGeneration(generation) || !request.direction || typeof request.direction!=='object'
        || request.payload!==undefined && !hexOK(request.crm_values_sha256)) refuse('screen_admission_request_invalid');
    if(typeof this.publisher?.prepareScreen!=='function') refuse('screen_admission_publisher_unavailable');
    const control=(await this.control.get()).data(); this.fence(control); this.screenGate(control,request);
    const ref=this.saRef(id),counts=meta=>({rows:meta.rows,duplicates:meta.duplicates});
    let meta=(await ref.get()).data() || null;
    if(meta?.state==='acknowledged') return {state:'acknowledged',...counts(meta)};
    let state=meta?JSON.parse(Buffer.from(await this.blobGet(meta.blob),'base64').toString('utf8')):null;
    if(state && (state.schema_version!==SA_STATE || state.admission_id!==id || state.generation!==generation))
      refuse('screen_admission_state_invalid');
    if(!meta || meta.state==='replan' && !meta.claimed) {
      if(request.payload===undefined) refuse('screen_admission_payload_required');
      const problem=screenPayloadProblem(request.payload,id);
      if(problem) refuse(problem);
      const object=await this.screenAdmissionObjectGet(id,generation,null);
      let bundle;try {bundle=JSON.parse(Buffer.from(object.data,'base64').toString('utf8'));} catch {refuse('screen_admission_bundle_invalid');}
      this.saBundleBinding(bundle,request.payload);
      const bundleBlob=await this.blobPut(object.data);
      let plan;
      try {plan=await this.publisher.prepareScreen(request.payload,request.crm_values_sha256);}
      catch(error) {throw new Refusal(saCode(error?.message) || /^publication_[a-z_]+$/.test(error?.message || '')?error.message:'screen_admission_plan_unavailable');}
      state={schema_version:SA_STATE,admission_id:id,generation,bundle_blob:bundleBlob,direction:request.direction,
        approval_reference:control.screen_admission.current.approval_reference,payload:request.payload,plan,
        planned_at:new Date(this.clock()).toISOString()};
      meta=await this.saPut(ref,state,'planned',meta?.blob ?? null);
    }
    const pending={state:'write_uncertain',...counts(meta)};
    let receipt;
    try {receipt=await this.publisher.reconcileScreen(state.payload,state.plan);}
    catch(error) {throw new Refusal(/^(?:publication|screen_admission)_[a-z_]+$/.test(error?.message || '')?error.message:'screen_admission_readback_unavailable');}
    if(!receipt) {
      if(meta.claimed) return pending;  // A claimed write is reconciled by reading only, never written again.
      // Before the claim: the CRM must still be exactly the plan's; otherwise a fresh plan, since nothing was written.
      const current=await this.crmReader();
      if(valueHash(current?.values ?? null)!==valueHash(state.plan.crm_values)) {
        await this.transaction(async tx=>{
          const control=(await tx.get(this.control)).data(); await this.publicationFence(tx,control);
          const now=(await tx.get(ref)).data();
          if(now?.blob!==meta.blob || now.claimed) refuse('screen_admission_state_changed');
          tx.set(ref,{state:'replan'},{merge:true});
        });
        return {state:'replan_required',...counts(meta)};
      }
      await this.transaction(async tx=>{
        const control=(await tx.get(this.control)).data(); await this.publicationFence(tx,control); this.screenGate(control,request);
        const now=(await tx.get(ref)).data();
        if(now?.blob!==meta.blob || now.claimed || now.state!=='planned') refuse('screen_admission_state_changed');
        tx.set(ref,{claimed:state.plan.request_digest,claimed_at:new Date(this.clock()).toISOString()},{merge:true});
      });
      // One write; whatever it answers, the outcome is then only read back (a lost reply may still have landed).
      try {
        await this.publisher.writeScreen(state.payload,state.plan,{beforeWrite:async()=>{
          await this.transaction(async tx=>{
            const control=(await tx.get(this.control)).data();await this.publicationFence(tx,control);this.screenGate(control,request);
          });
        }});
      } catch { /* uncertain until the readback shows the rows */ }
      try {receipt=await this.publisher.reconcileScreen(state.payload,state.plan);} catch {return pending;}
      if(!receipt) return pending;
    }
    const done={...state,receipt,acknowledged_at:new Date(this.clock()).toISOString()};
    const hash=await this.blobPut(Buffer.from(JSON.stringify(done)).toString('base64'));
    return this.transaction(async tx=>{
      const control=(await tx.get(this.control)).data(); await this.publicationFence(tx,control);
      const itemRef=this.db.doc(`${ROOT}/screenWorkItems/${id}`),now=(await tx.get(ref)).data(),item=await tx.get(itemRef);
      if(now?.state==='acknowledged') return {state:'acknowledged',...counts(now)};
      if(now?.blob!==meta.blob || item.exists) refuse('screen_admission_state_changed');
      tx.set(ref,{...now,blob:hash,state:'acknowledged',acknowledged_at:done.acknowledged_at});
      tx.set(itemRef,{schema_version:SA_WORK_ITEM,admission_id:id,stage:'completed',state_blob:hash,bundle_blob:state.bundle_blob,
        sheets_receipt:receipt.reference,rows:now.rows,duplicates:now.duplicates,completed_at:done.acknowledged_at,
        owner:'blueprint-communications-agent',scope:'hypothesis_draft_only_no_send',sends_authorized:false});
      return {state:'acknowledged',...counts(now)};
    });
  }
  async screenSnapshot(id) {
    // The WebApp's read of one completed admission: the work item, the acknowledged state and the bundle bytes. Reads only.
    if(!hexOK(id)) refuse('screen_admission_id_invalid');
    const item=await this.db.doc(`${ROOT}/screenWorkItems/${id}`).get(),meta=(await this.saRef(id).get()).data();
    if(!item.exists) refuse('screen_admission_work_item_missing');
    if(meta?.state!=='acknowledged' || meta.blob!==item.data().state_blob) refuse('screen_admission_snapshot_binding_invalid');
    const state=JSON.parse(Buffer.from(await this.blobGet(meta.blob),'base64').toString('utf8'));
    if(state.admission_id!==id || state.bundle_blob!==item.data().bundle_blob || state.bundle_blob!==id)
      refuse('screen_admission_snapshot_binding_invalid');
    return {schema_version:SA_SNAPSHOT,admission_id:id,work_item:item.data(),state,bundle:await this.blobGet(state.bundle_blob)};
  }
  async workItem() {
    const queue=this.db.collection(`${ROOT}/workItems`);
    const groups=await Promise.all(['validation_repair_pending','agent_qa_pending','publication_pending']
      .map(stage=>queue.where('stage','==',stage).limit(21).get()));
    if (groups.some(group=>group.docs.length>20)) refuse('workflow_queue_limit');
    const items=groups.flatMap(group=>group.docs.map(s=>s.data())).sort((a,b)=>a.date.localeCompare(b.date));
    return items[0] || null;
  }
  async activeQA() {
    const runs=this.db.collection(`${ROOT}/runs`);
    const groups=await Promise.all([
      ...['qa_running','qa_input_unresolved','qa_correction_input_unresolved','qa_cancel_pending'].map(state=>['qa_state',state]),
      ...['running','input_unresolved','cancel_pending'].map(state=>['repair_state',state]),
      ...['running','input_unresolved','cancel_pending'].map(state=>['publication_state',state])]
      .map(([field,state])=>runs.where(field,'==',state).limit(1).get()));
    const days=groups.flatMap(s=>s.docs.map(d=>d.id)).sort();
    return days[0] || null;
  }
  async qaCheck(day,requestDigest,deadlineMS) {
    if (!dateOK(day) || !/^[a-f0-9]{64}$/.test(requestDigest)) refuse('agent_qa_request_invalid');
    return this.transaction(async tx=>{
      const control=(await tx.get(this.control)).data();this.fence(control);this.workflowGate(control);
      const ref=this.db.doc(`${ROOT}/runs/${day}`),snap=await tx.get(ref),run=snap.data();
      if (!snap.exists || run.state!=='awaiting_review' || run.qa_state!=='qa_input_unresolved'
          || run.qa_request_digest!==requestDigest || run.qa_request_claimed
          || !Number.isSafeInteger(deadlineMS) || run.qa_deadline_ms!==deadlineMS
          || this.clock()>=deadlineMS) refuse('agent_qa_input_not_admitted');
      this.budgetGate(control, run);
      tx.set(ref,{qa_request_claimed:true},{merge:true});return true;
    });
  }
  async qaRetryCheck(day, requestDigest, deadlineMS, number) {
    if (!dateOK(day) || !/^[a-f0-9]{64}$/.test(requestDigest) || ![1,2].includes(number))
      refuse('qa_retry_request_invalid');
    return this.transaction(async tx=>{
      const control=(await tx.get(this.control)).data();this.fence(control);this.workflowGate(control);
      const ref=this.db.doc(`${ROOT}/runs/${day}`),snap=await tx.get(ref),run=snap.data();
      const error=run?.qa_retry_prior_503;
      if (!snap.exists || run.state!=='awaiting_review' || run.qa_state!=='qa_input_unresolved'
          || run.qa_request_claimed!==true || run.qa_request_digest!==requestDigest
          || (!run.qa_retry_phase_digest && !run.qa_submission_binding_digest) || run.qa_retry_number!==number
          || (run.qa_retry_workflow_authority && run.qa_retry_workflow_authority!==control.workflow.qa_authority_reference)
          || run.qa_retry_key!==`blueprint-researcher:${day}:qa`
          || !Number.isSafeInteger(deadlineMS) || run.qa_retry_deadline_ms!==deadlineMS
          || !Number.isSafeInteger(run.qa_retry_not_before_ms) || this.clock()<run.qa_retry_not_before_ms
          || this.clock()>=deadlineMS || run.qa_retry_claims?.[number]
          || (number===2 && run.qa_retry_claims?.[1]!==requestDigest)
          || error?.stage!=='provider_submission' || error.http_status!==503
          || !['service_unavailable_error','server_is_overloaded'].includes(error.code))
        refuse('qa_retry_input_not_admitted');
      this.budgetGate(control,run);
      tx.set(ref,{qa_retry_claims:{...run.qa_retry_claims,[number]:requestDigest}},{merge:true});return true;
    });
  }
  async qaCorrectionCheck(day, requestDigest, deadlineMS, number) {
    if (!dateOK(day) || !/^[a-f0-9]{64}$/.test(requestDigest) || ![1,2].includes(number))
      refuse('qa_correction_request_invalid');
    return this.transaction(async tx=>{
      const control=(await tx.get(this.control)).data();this.fence(control);this.workflowGate(control);
      const ref=this.db.doc(`${ROOT}/runs/${day}`),snap=await tx.get(ref),run=snap.data();
      const binding=run?.qa_correction_bindings?.[number];
      if (!snap.exists || run.state!=='awaiting_review' || run.qa_state!=='qa_correction_input_unresolved'
          || run.qa_request_claimed!==true || run.qa_correction_number!==number
          || run.qa_correction_state!=='input_unresolved' || binding?.request_digest!==requestDigest
          || binding.authority_reference!==control.workflow.qa_authority_reference
          || (run.qa_retry_workflow_authority && binding.authority_reference!==run.qa_retry_workflow_authority)
          || binding.idempotency_key!==`blueprint-researcher:${day}:qa:correction:${number}`
          || !/^[a-f0-9]{64}$/.test(binding.previous_review?.artifact_digest || '')
          || binding.previous_review?.turn_status!=='completed'
          || !Number.isSafeInteger(deadlineMS) || binding.deadline_ms!==deadlineMS
          || (run.qa_retry_deadline_ms || run.qa_deadline_ms)!==deadlineMS || this.clock()>=deadlineMS
          || run.qa_correction_claims?.[number] || (number===2 && !run.qa_correction_claims?.[1]))
        refuse('qa_correction_input_not_admitted');
      this.budgetGate(control,run);
      tx.set(ref,{qa_correction_claims:{...run.qa_correction_claims,[number]:requestDigest}},{merge:true});return true;
    });
  }
  publicationAgentGate(control,row,requestDigest,action=null) {
    this.fence(control);this.workflowGate(control);this.budgetGate(control,row || {});
    const p=row?.publication;
    if(row?.publication_profile!=='agent-owned-v1' || p?.profile!=='agent-owned-v1'
        || row.state!=='reviewed' || row.qa?.state!=='validated' || !/^[a-f0-9]{64}$/.test(requestDigest || '')
        || p.request_digest!==requestDigest || p.input_file!==`${row.date}-publication-input.json`
        || p.idempotency_key!==`${row.run_key}:publication` || !Number.isSafeInteger(p.deadline_ms)
        || p.deadline_ms<=this.clock() || p.authority_reference!==control.workflow.publication_authority_reference
        || !p.workflow_authority || !same(p.workflow_authority,control.workflow)
        || typeof row.session_id!=='string' || !row.session_id || p.session_id!==row.session_id)
      refuse('publication_agent_input_not_admitted');
    if(action) {
      const intent=row.application_tool_calls?.[action.call_id];
      let exactRequest;try {exactRequest=JSON.parse(intent?.request_json);}catch {}
      if(p.state!=='running' || typeof action.turn_id!=='string' || action.turn_id!==p.turn_id
          || typeof action.call_id!=='string' || !action.call_id || intent?.phase!=='publication'
          || intent.attempted!==true || typeof intent.request_json!=='string' || intent.request_digest!==sha(intent.request_json)
          || valueHash(exactRequest || null)!==valueHash(action)
          || valueHash(intent.request)!==valueHash(action)) refuse('publication_agent_tool_not_admitted');
    }
  }
  async publicationInputCheck(day,requestDigest,deadlineMS) {
    const row=await this.get(day),ref=this.db.doc(`${ROOT}/runs/${day}`),before=await ref.get();
    if(!row?.publication?.input_file) refuse('publication_input_binding_invalid');
    const input=Buffer.from(await this.fileGet(row.publication.input_file),'base64');
    let event;try {event=JSON.parse(input.toString('utf8'));}catch {refuse('publication_input_binding_invalid');}
    if(input.at(-1)!==10 || sha(input.subarray(0,-1))!==requestDigest || event?.type!=='agent.session.input.message')
      refuse('publication_input_binding_invalid');
    return this.transaction(async tx=>{
      const control=(await tx.get(this.control)).data();this.publicationAgentGate(control,row,requestDigest);
      const run=(await tx.get(ref)).data();
      if(row.publication.state!=='input_unresolved' || row.publication.deadline_ms!==deadlineMS
          || run.blob!==before.data().blob || run.publication_input_claimed
          || run.publication_request_digest!==requestDigest || run.publication_deadline_ms!==deadlineMS)
        refuse('publication_agent_input_not_admitted');
      tx.set(ref,{publication_input_claimed:true},{merge:true});return true;
    });
  }
  async admitRejectedPresentation(row,presentation,context) {
    const name='notion',d=row.delivery[name],ref=this.db.doc(`${ROOT}/runs/${row.date}`),before=(await ref.get()).data();
    const state=attemptState(before,row,name),rejection=state.rejection;
    if(!state.claimed || !rejection || rejection.request_digest!==state.claimed
        || rejection.plan_digest!==valueHash(d.plan) || Object.keys(state.batches || {}).some(n=>n!=='0'))
      refuse('publication_presentation_already_bound');
    const raw=Buffer.from(await this.blobGet(rejection.response_blob),'base64').toString('utf8');
    let body;try {body=JSON.parse(raw);}catch {refuse('publication_rejection_receipt_invalid');}
    if(sha(raw)!==rejection.response_digest || body.object!=='error' || body.status!==400
        || body.code!=='validation_error' || rejection.http_status!==400)
      refuse('publication_rejection_receipt_invalid');
    const observation=await this.publisher.notionProgress(row,d.plan);
    if(!observation.absence_verified || observation.receipt) refuse('publication_rejection_absence_not_verified');
    const number=(d.attempt_number || 0)+1;
    const pending=before.publication_attempts?.[name]?.[number];
    if(pending && (pending.prior_attempt!==(d.attempt_number || 0) || pending.rejection_digest!==rejection.response_digest
        || pending.presentation_digest!==(presentation?.decision_digest || null) || pending.claimed || pending.archived))
      refuse('publication_attempt_not_admitted');
    await this.transaction(async tx=>{
      const control=(await tx.get(this.control)).data();this.publicationAgentGate(control,row,context.request_digest,context.action);
      requirePublicationVerification(row,name,this.clock());
      const run=(await tx.get(ref)).data();
      if(run.blob!==before.blob || valueHash(attemptState(run,row,name))!==valueHash(state)
          || valueHash(run.publication_attempts?.[name]?.[number] || null)!==valueHash(pending || null))
        refuse('publication_attempt_not_admitted');
      if(pending) return;
      const priorNumber=d.attempt_number || 0;
      tx.set(ref,{publication_attempts:{...run.publication_attempts,[name]:{...run.publication_attempts?.[name],
        [priorNumber]:{...state,source_row_blob:run.blob,archived:true},
        [number]:{prior_attempt:priorNumber,rejection_digest:rejection.response_digest,
          presentation_digest:presentation?.decision_digest || null,absence_verified:true}}}},{merge:true});
    });
    d.attempt_number=number;delete d.plan;d.presentation=presentation;
    await this.put(row);
  }
  async publicationAgentTool(day,action,requestDigest) {
    let destination, row, argumentIssues;
    const invalidArguments=issues=>{argumentIssues=issues;refuse('publication_agent_tool_arguments_invalid');};
    try {
      row=await this.get(day);
      const control=(await this.control.get()).data();this.publicationAgentGate(control,row,requestDigest,action);
      let args=action?.arguments;
      if(typeof args==='string') {try {args=JSON.parse(args);}catch {invalidArguments([{path:'/',code:'invalid_json',
        expectations:{type:'object'},allowed_repair:'Provide one JSON object matching the declared publication tool fields.'}]);}}
      if(action?.name==='blueprint_inspect_publication' && args==null) args={};
      if(!action || !['blueprint_inspect_publication','blueprint_publish_research'].includes(action.name)
          || !args || typeof args!=='object' || Array.isArray(args))
        invalidArguments([{path:'/',code:'invalid_type',expectations:{type:'object'},
          allowed_repair:'Use a declared publication tool with one arguments object.'}]);
      const ref=this.db.doc(`${ROOT}/runs/${day}`),run=(await ref.get()).data();
      if(!run.publication_input_claimed) refuse('publication_agent_input_not_claimed');
      if(action.name==='blueprint_inspect_publication') {
        if(Object.keys(args).length) invalidArguments([{path:'/',code:'unexpected_properties',expectations:{allowed_properties:[]},
          allowed_repair:'Call blueprint_inspect_publication with an empty object.'}]);
        return {success:true,output:{validated_research:row.qa.decision || null,packet:row.packet,
          lead_verification:row.review?.lead_verification || null,
          verification_eligibility:Object.fromEntries(Object.keys(row.delivery || {}).map(name=>[name,publicationVerification(row,name,this.clock(),
            {withheld:this.outreachUnbound(run,row)?'outreach_ready_unbound':null})])),
          destinations:Object.fromEntries(Object.entries(row.delivery || {}).map(([name,d])=>[name,{
            key:d.key,payload:d.payload,payload_digest:d.payload_digest,presentation:d.presentation || null,
            state:d.state,receipt:d.receipt || null,plan:d.plan || null,
            claimed:!!attemptState(run,row,name).claimed,batches:attemptState(run,row,name).batches || {},
            rejection:attemptState(run,row,name).rejection || null,attempts:run.publication_attempts?.[name] || {}}])),
          transport_limits:{notion:{blocks_per_request:90,utf8_json_bytes_per_request:450000,text_code_units_per_block:1800}},
          presentation_rules:{sheets:{strategies:['full'],summary:'must_be_absent',example:{destination:'sheets',strategy:'full'}},
            notion:{full:{summary:'must_be_absent'},concise:{summary:'required_nonblank',max_utf8_bytes:2000000}}},
          guidance:'Sheets requires full with summary omitted. Notion permits full with summary omitted or concise with a nonblank summary up to 2,000,000 UTF-8 bytes. Choose before a write claim. A current protected evidence assessment is required before every new candidate publication claim or batch. Missing or expired evidence stays unresolved; inspect its reasons and retain raw research. Buying intent, rights, commercial qualification, robot compatibility and deployment readiness require separate gates. Unknown writes are observation-only; never replace a consumed plan.'}};
      }
      const a=args;destination=a.destination;
      const issues=[];
      if(Object.keys(a).some(key=>!['destination','strategy','summary'].includes(key)))
        issues.push({path:'/',code:'unexpected_properties',expectations:{allowed_properties:['destination','strategy','summary']},
          allowed_repair:'Remove undeclared fields; keep the original request retained.'});
      if(!['notion','sheets'].includes(destination)) issues.push({path:'/destination',code:'invalid_enum',
        expectations:{allowed_values:['notion','sheets']},allowed_repair:'Select one already approved destination: notion or sheets.'});
      if(!['full','concise'].includes(a.strategy) || destination==='sheets' && a.strategy!=='full')
        issues.push({path:'/strategy',code:'invalid_enum',expectations:{allowed_values:destination==='sheets'?['full']:['full','concise']},
          allowed_repair:destination==='sheets'?'Use {"destination":"sheets","strategy":"full"} with summary omitted.':'Choose full or concise; concise is available only for Notion.'});
      if((destination==='sheets' || a.strategy==='full') && a.summary!==undefined)
        issues.push({path:'/summary',code:'field_must_be_absent',expectations:{present:false},
          allowed_repair:'Omit summary for Sheets and every full presentation; original canonical research remains retained.'});
      if(destination==='notion' && a.strategy==='concise' && (typeof a.summary!=='string'
          || !a.summary.trim() || Buffer.byteLength(a.summary)>2000000))
        issues.push({path:'/summary',code:'invalid_summary',expectations:{type:'string',nonblank:true,max_utf8_bytes:2000000},
          allowed_repair:'Supply a supported nonblank Notion summary within 2,000,000 UTF-8 bytes, or choose full and omit summary.'});
      if(issues.length) invalidArguments(issues);
      const d=row.delivery?.[destination];if(!d) refuse('publication_destination_invalid');
      let presentation=null;
      if(a.strategy==='concise') {
        const decision_json=JSON.stringify({destination,strategy:a.strategy,summary:a.summary,source_payload_digest:d.payload_digest});
        presentation={schema_version:'blueprint.research-presentation.v1',strategy:a.strategy,summary:a.summary,
          source_payload_digest:d.payload_digest,decision_json,decision_digest:sha(decision_json)};
      }
      if((d.plan || attemptState(run,row,destination).claimed || d.state==='acknowledged')
          && valueHash(d.presentation || null)!==valueHash(presentation)) {
        if(destination!=='notion' || d.state==='acknowledged') refuse('publication_presentation_already_bound');
        await this.admitRejectedPresentation(row,presentation,{request_digest:requestDigest,action});
      }
      if(valueHash(d.presentation || null)!==valueHash(presentation)) {d.presentation=presentation;await this.put(row);}
      const receipt=d.state==='acknowledged'?d.receipt:await this.publish(day,destination,{request_digest:requestDigest,action});
      const latest=(await ref.get()).data();
      return {success:true,output:{destination,status:receipt?'acknowledged':'pending',
        mutation_policy:attemptState(latest,row,destination).claimed?'reconcile_exact_claims_only':'not_claimed',
        canonical_payload_digest:d.payload_digest,presentation_digest:presentation?.decision_digest || null,
        guidance:receipt?'Exact destination readback verified.':'Inspect and retry the same choice to reconcile or advance verified ordered batches; never resend an unobserved claimed request.'},...(receipt?{receipt}:{})};
    } catch(error) {
      const code=/^(?:publication|workflow|firestore|research_tool)_[a-z_]{1,100}$/.test(error.message)
        ?error.message:'publication_attempt_unresolved';
      let evidence_file,definitive_rejection=false;
      if(typeof error.provider_response==='string') {
        evidence_file=`${day}-tool-publication-error-${sha(error.provider_response)}.json`;
        try {await this.filePut(evidence_file,Buffer.from(error.provider_response).toString('base64'));}catch {evidence_file=null;}
        let parsed;try {parsed=JSON.parse(error.provider_response);}catch {}
        if(destination==='notion' && error.provider_feedback?.http_status===400 && parsed?.object==='error'
            && parsed.status===400 && parsed.code==='validation_error'
            && sha(error.provider_response)===error.provider_feedback.response_digest) {
          try {
            const current=await this.get(day),ref=this.db.doc(`${ROOT}/runs/${day}`),before=(await ref.get()).data();
            const state=attemptState(before,current,destination),plan=current.delivery.notion.plan;
            const response_blob=await this.blobPut(Buffer.from(error.provider_response).toString('base64'));
            if(state.claimed===error.provider_feedback.request_digest && plan?.request_digest===state.claimed
                && !Object.keys(state.batches || {}).some(n=>n!=='0')) {
              const rejection={http_status:400,provider_code:'validation_error',response_blob,
                response_digest:sha(error.provider_response),request_digest:state.claimed,plan_digest:valueHash(plan)};
              await this.transaction(async tx=>{
                const control=(await tx.get(this.control)).data();this.publicationAgentGate(control,current,requestDigest,action);
                const run=(await tx.get(ref)).data();
                if(run.blob!==before.blob || valueHash(attemptState(run,current,destination))!==valueHash(state))
                  refuse('publication_attempt_not_admitted');
                if(current.delivery.notion.attempt_number) tx.set(ref,{publication_attempts:{...run.publication_attempts,
                  notion:{...run.publication_attempts?.notion,[current.delivery.notion.attempt_number]:{...state,rejection}}}},{merge:true});
                else tx.set(ref,{publication_rejections:{...run.publication_rejections,notion:rejection}},{merge:true});
              });
              definitive_rejection=true;
            }
          } catch { /* Failed rejection proof never grants another write. */ }
        }
      }
      return {success:false,error:{code,destination:destination || null,
        ...(argumentIssues?{status:'recoverable_issue',issues:argumentIssues,
          allowed_repair:'Correct the indicated arguments in this same turn within current authority. Inspect claims before changing a presentation; existing claims and receipts remain binding.'}:{}),
        ...(code==='publication_lead_verification_required'?{status:'recoverable_issue',
          evidence_issues:publicationVerification(row,destination,this.clock()).reasons,
          allowed_repair:'Inspect the retained evidence and reasons. Supply a supported current assessment through the existing protected research review within original authority; preserve raw findings and consumed claims. Do not invent qualification or repeat uncertain writes.'}:{}),
        recovery_policy:argumentIssues?'repair_arguments_preserve_claims':definitive_rejection?'new_agent_presentation_after_verified_absence':'preserve_claims_and_inspect',
        guidance:code==='publication_lead_verification_required'?'Current evidence verification is required for a new qualified candidate claim or batch. Raw source and existing readback remain available; missing evidence is unresolved, with all commercial and rights gates still separate.':argumentIssues?'Sheets requires full with summary omitted; Notion permits full without summary or concise with a supported nonblank summary. Original requests remain retained; argument repair grants no new authority.':definitive_rejection
          ?'The provider definitively rejected the initial create request. Choose a revised presentation; a new attempt is admitted only after complete readback proves the report absent. Original plan, claim and error remain retained.'
          :'Inspect retained source and current claims. An uncertain write is GET-only until exact readback; choose a revised presentation before a claim or after a proven initial validation rejection.',
        ...(error.provider_feedback?{provider_feedback:error.provider_feedback}:{}),
        ...(typeof error.provider_response==='string'?{provider_response_json:error.provider_response}:{}),
        ...(evidence_file?{evidence_file}:{})}};
    }
  }
  terminalSheetsGate(control,row,context) {
    this.fence(control);
    const source=context.source,original=source.publication,projection=structuredClone(row);
    for(const key of ['plan','receipt','state']) delete projection.delivery?.sheets?.[key];
    const expected=structuredClone(source);
    for(const key of ['plan','receipt','state']) delete expected.delivery.sheets[key];
    const authority=control.workflow,stored=original.workflow_authority;
    if(this.schedulerStopped!==true || control.enabled!==false || control.config?.enabled!==false
        || !authority || typeof authority.enabled!=='boolean'
        || Object.keys(authority).sort().join(',')!=='enabled,publication_authority_reference,qa_authority_reference'
        || authority.publication_authority_reference!==context.publication_authority_reference
        || authority.publication_authority_reference!==stored.publication_authority_reference
        || authority.qa_authority_reference!==stored.qa_authority_reference
        || valueHash(projection)!==valueHash(expected)) refuse('terminal_sheets_recovery_not_admitted');
  }
  async recoverTerminalSheets(request) {
    const keys=['op','day','source_row_blob','payload_digest','rejected_call_id','publication_authority_reference'];
    if(Object.keys(request).sort().join(',')!==keys.sort().join(',') || !dateOK(request.day)
        || !['source_row_blob','payload_digest'].every(k=>/^[a-f0-9]{64}$/.test(request[k] || ''))
        || !/^[A-Za-z0-9_-]{1,200}$/.test(request.rejected_call_id || '')
        || typeof request.publication_authority_reference!=='string') refuse('terminal_sheets_recovery_request_invalid');
    const source=JSON.parse(Buffer.from(await this.blobGet(request.source_row_blob),'base64').toString('utf8'));
    const p=source.publication,d=source.delivery?.sheets,review=source.review,qa=source.qa;
    // This recovery re-derives only the verified Sheets payload. On a day with hypotheses it still
    // recovers the verified rows and withholds every hypothesis (publish passes the reason to the plan):
    // their QA listing and protected review are not part of what the recovery proves.
    if(source.date!==request.day || source.run_key!==`blueprint-researcher:${request.day}` || source.canary
        || source.state!=='reviewed' || source.publication_profile!=='agent-owned-v1'
        || !source.session_id || !source.turn_id || qa?.state!=='validated' || !qa.turn_id
        || p?.profile!=='agent-owned-v1' || p.session_id!==source.session_id || !p.turn_id
        || p.turn_status!=='completed' || p.state!=='agent_finished_without_complete_receipts'
        || !Number.isSafeInteger(p.completed_at) || !Number.isSafeInteger(p.deadline_ms)
        || p.completed_at*1000>p.deadline_ms || p.cancel_attempted || p.observation_only_reason
        || !Array.isArray(p.baseline_turn_ids) || ![source.turn_id,qa.turn_id].every(id=>p.baseline_turn_ids.includes(id))
        || p.idempotency_key!==source.run_key+':publication' || !p.workflow_authority
        || p.authority_reference!==request.publication_authority_reference
        || p.workflow_authority.publication_authority_reference!==p.authority_reference
        || review?.source_support_verified!==true || review.crm_rechecked!==true
        || review.packet_digest!==source.packet_digest || pythonHash(source.packet)!==source.packet_digest
        || review.qa_artifact_digest!==qa.artifact_digest || verificationDigest(qa.decision)!==verificationDigest(review)
        || ![`${source.date}-qa.json`,`${source.date}-qa-correction-1-artifact.json`,`${source.date}-qa-correction-2-artifact.json`].includes(qa.artifact_file)
        || review.reviewer_reference!==`agent-turn:${source.session_id}:${qa.turn_id}`
        || !Array.isArray(review.accepted_keys) || !review.accepted_keys.length
        || new Set(review.accepted_keys).size!==review.accepted_keys.length
        || d?.state!=='pending' || d.presentation || d.plan || d.receipt || d.attempt_number
        || source.delivery.notion?.state!=='acknowledged' || source.delivery.notion.receipt?.readback_verified!==true
        || source.delivery.notion.receipt.key!==source.run_key+':notion'
        || source.delivery.notion.receipt.payload_digest!==source.delivery.notion.payload_digest
        || d.key!==source.run_key+':sheets' || d.payload_digest!==request.payload_digest)
      refuse('terminal_sheets_recovery_source_invalid');
    const input=Buffer.from(await this.fileGet(p.input_file),'base64');
    if(p.input_file!==`${source.date}-publication-input.json` || input.at(-1)!==10
        || sha(input.subarray(0,-1))!==p.request_digest) refuse('terminal_sheets_recovery_evidence_invalid');
    const selected=source.packet.candidates.filter(c=>review.accepted_keys.includes(c.candidate_key));
    if(selected.length!==review.accepted_keys.length || valueHash(selected)!==valueHash(d.payload?.candidates)
        || d.payload.sheet_id!=='1n95Ih0Swc-q-kZyUaDHoZh6SVzxvf_zt-CRR7i39bWY' || d.payload.tab!=='Prospects'
        || typeof d.payload_json!=='string' || sha(d.payload_json)!==d.payload_digest
        || valueHash(JSON.parse(d.payload_json))!==valueHash(d.payload)) refuse('terminal_sheets_recovery_payload_invalid');
    const rawQA=Buffer.from(await this.fileGet(qa.artifact_file),'base64');
    let qaResult;try {qaResult=JSON.parse(rawQA.toString('utf8'));}catch {refuse('terminal_sheets_recovery_qa_invalid');}
    if(sha(rawQA)!==qa.artifact_digest || qaResult.packet_digest!==source.packet_digest
        || qaResult.source_support_verified!==true || !Array.isArray(qaResult.accepted_keys)
        || !review.accepted_keys.every(key=>qaResult.accepted_keys.includes(key))) refuse('terminal_sheets_recovery_qa_invalid');
    if(review.lead_verification) for(const result of review.lead_verification.results || []) {
      const check=qaResult.checks?.find(check=>check.candidate_key===result.candidate_key);
      if(!check || verificationDigest(check.lead_verification ?? null)!==verificationDigest(result.assessment ?? null)
          || result.assessment_digest!==verificationDigest(result.assessment ?? null))
        refuse('terminal_sheets_recovery_qa_invalid');
    }
    const evidence=JSON.parse(Buffer.from(await this.fileGet(p.evidence_file),'base64').toString('utf8'));
    if(p.evidence_file!==`${source.date}-publication-evidence.json` || !Array.isArray(evidence)
        || evidence.some(item=>item.turn_id!==p.turn_id) || pythonHash(evidence)!==p.evidence_digest)
      refuse('terminal_sheets_recovery_evidence_invalid');
    const call=source.application_tool_calls?.[request.rejected_call_id],action=call?.request;
    let args;try {args=typeof action?.arguments==='string'?JSON.parse(action.arguments):action?.arguments;}catch {}
    if(call?.phase!=='publication' || call.attempted!==true || call.success!==false || call.result_acknowledged!==true
        || action?.call_id!==request.rejected_call_id || action.turn_id!==p.turn_id
        || action.name!=='blueprint_publish_research' || args?.destination!=='sheets' || args.strategy!=='concise'
        || typeof call.request_json!=='string' || sha(call.request_json)!==call.request_digest
        || valueHash(JSON.parse(call.request_json))!==valueHash(action)
        || call.result_file!==`${source.date}-tool-${action.call_id}.json`) refuse('terminal_sheets_recovery_rejection_invalid');
    const raw=Buffer.from(await this.fileGet(call.result_file),'base64'),event=JSON.parse(raw.toString('utf8'));
    const outcome=JSON.parse(event.output);
    if(sha(raw)!==call.result_sha256 || pythonHash(event)!==call.result_digest || event.success!==false
        || event.call_id!==action.call_id || event.turn_id!==p.turn_id || outcome.success!==false
        || outcome.error?.code!=='publication_agent_tool_arguments_invalid' || outcome.error.destination!=='sheets')
      refuse('terminal_sheets_recovery_rejection_invalid');
    const context={...request,source},row=await this.get(request.day),control=(await this.control.get()).data();
    this.terminalSheetsGate(control,row,context);
    const recoveryRef=this.db.doc(`${ROOT}/terminalSheetsRecoveries/${request.source_row_blob}`);
    const binding={source_row_blob:request.source_row_blob,payload_digest:d.payload_digest,rejected_call_id:action.call_id,
      rejection_result_sha256:call.result_sha256,qa_artifact_digest:qa.artifact_digest,
      publication_evidence_digest:p.evidence_digest,publication_authority_reference:p.authority_reference};
    context.recoveryRef=recoveryRef;context.binding=binding;
    const receipt=await this.publish(request.day,'sheets',null,context);
    if(!receipt) return {state:'readback_pending',mutation_policy:'existing_claim_readback_only',recovery_ref:recoveryRef.path};
    if(receipt.destination!=='sheets' || receipt.payload_digest!==d.payload_digest || receipt.key!==d.key
        || receipt.readback_verified!==true || !receipt.reference) refuse('terminal_sheets_recovery_receipt_invalid');
    const current=await this.get(request.day);this.terminalSheetsGate((await this.control.get()).data(),current,context);
    if(current.delivery.sheets.receipt && valueHash(current.delivery.sheets.receipt)!==valueHash(receipt))
      refuse('delivery_receipt_already_bound');
    const expected_blob=sha(JSON.stringify(current));
    current.delivery.sheets.receipt=receipt;current.delivery.sheets.state='acknowledged';
    await this.put(current,{expected_blob,context});
    await this.transaction(async tx=>{
      const ctrl=(await tx.get(this.control)).data();this.terminalSheetsGate(ctrl,current,context);
      const saved=(await tx.get(recoveryRef)).data();
      if(!saved || valueHash(saved.binding)!==valueHash(binding)) refuse('terminal_sheets_recovery_binding_changed');
      if(saved.receipt && valueHash(saved.receipt)!==valueHash(receipt)) refuse('delivery_receipt_already_bound');
      if(!saved.receipt) tx.set(recoveryRef,{...saved,receipt,state:'acknowledged',readback_at:new Date(this.clock()).toISOString()});
    });
    return {state:'acknowledged',receipt,recovery_ref:recoveryRef.path,original_publication_state:p.state};
  }
  async publish(day,selectedDestination=null,agentContext=null,terminalRecovery=null) {
    await this.assertLease(); const initialControl=(await this.control.get()).data();
    if(terminalRecovery) this.terminalSheetsGate(initialControl,await this.get(day),terminalRecovery);
    else this.workflowGate(initialControl,!!this.terminalCollectionReceipt);
    if (!this.publisher) refuse('publication_binding_unavailable');
    const row=await this.get(day);
    if(row?.publication_profile==='agent-owned-v1' && !terminalRecovery) {
      if(!agentContext || !selectedDestination) refuse('publication_agent_choice_required');
      this.publicationAgentGate(initialControl,row,agentContext.request_digest,agentContext.action);
    }
    const proof=this.terminalCollectionReceipt;
    if (proof && (!['reviewed','completed'].includes(row?.state) || row?.qa?.state!=='validated'
        || valueHash(row.qa.terminal_collection_recovery?.native_receipt||null)!==valueHash(proof)
        || row.session_id!==proof.session_id || row.qa.artifact_digest!==proof.qa_artifact_sha256))
      refuse('terminal_qa_collection_validated_receipt_required');
    const collectionAuthority=row?.qa?.terminal_collection_recovery?.workflow_authority;
    if (collectionAuthority && !same(collectionAuthority,initialControl.workflow)) refuse('publication_authority_changed');
    const destination=selectedDestination || ['notion','sheets'].find(name=>row?.delivery?.[name]?.state!=='acknowledged');
    if(selectedDestination && !['notion','sheets'].includes(selectedDestination)) refuse('publication_destination_invalid');
    if (!destination) return null;
    if(terminalRecovery && destination!=='sheets') refuse('terminal_sheets_recovery_request_invalid');
    const d=row.delivery[destination];
    try {
      if(terminalRecovery && attemptState((await this.db.doc(`${ROOT}/runs/${day}`).get()).data(),row,destination).claimed && !d.plan)
        refuse('terminal_sheets_recovery_claim_plan_missing');
      const withheld=terminalRecovery || d.payload?.hypotheses?.length
        ? await this.hypothesesWithheld(day,terminalRecovery,row) : null;
      const replan=withheld && d.plan?.hypothesis_keys?.length;
      if(replan) {
        const run=(await this.db.doc(`${ROOT}/runs/${day}`).get()).data(),state=attemptState(run,row,destination);
        // A consumed plan may already have an external effect. Preserve its exact readback,
        // but do not append any more batches after rollback loses hypothesis authority.
        if(state.claimed || Object.keys(state.batches || {}).length || d.receipt || d.state==='acknowledged')
          return await this.publisher.reconcile(row,destination,d.plan);
      }
      if (!d.plan || replan) {
        requirePublicationVerification(row,destination,this.clock());
        const expected_blob=terminalRecovery?sha(JSON.stringify(row)):null;
        d.plan=await this.publisher.prepare(row,destination,{withheld});
        await this.put(row,terminalRecovery?{expected_blob,context:terminalRecovery}:null);
      }
      if(terminalRecovery) await this.transaction(async tx=>{
        const control=(await tx.get(this.control)).data();this.terminalSheetsGate(control,row,terminalRecovery);
        const saved=(await tx.get(terminalRecovery.recoveryRef)).data(),plan_digest=valueHash(d.plan);
        if(saved && (valueHash(saved.binding)!==valueHash(terminalRecovery.binding) || saved.plan_digest!==plan_digest))
          refuse('terminal_sheets_recovery_binding_changed');
        if(!saved) tx.set(terminalRecovery.recoveryRef,{schema_version:'blueprint.terminal-sheets-recovery.v1',
          binding:terminalRecovery.binding,plan_digest,state:'prepared',prepared_at:new Date(this.clock()).toISOString()});
      });
      if(destination==='notion' && d.plan.protocol==='notion-paginated-v1')
        return await this.publishNotionBatch(row,d.plan,initialControl.workflow,collectionAuthority,proof,agentContext);
      const terminalBlob=terminalRecovery?sha(JSON.stringify(row)):null;
      const receipt=await this.publisher.reconcile(row,destination,d.plan);
      if (receipt) return receipt;
      const ref=this.db.doc(`${ROOT}/runs/${day}`),before=await ref.get();
      if(terminalRecovery && before.data().blob!==terminalBlob) refuse('publication_authority_or_plan_changed');
      if (attemptState(before.data(),row,destination).claimed) return null; // uncertain: GET reconciliation only
      await this.transaction(async tx=>{
        const control=(await tx.get(this.control)).data();this.fence(control);
        if(terminalRecovery) this.terminalSheetsGate(control,row,terminalRecovery);else this.workflowGate(control,!!proof);
        if (collectionAuthority && !same(collectionAuthority,control.workflow)) refuse('publication_authority_changed');
        const snap=await tx.get(ref),run=snap.data();
        if (run.blob!==before.data().blob || attemptState(run,row,destination).claimed) refuse('publication_attempt_not_admitted');
        this.hypothesisPlanGate(run,row,d.plan);
        if(agentContext) this.publicationAgentGate(control,row,agentContext.request_digest,agentContext.action);
        requirePublicationVerification(row,destination,this.clock());
        tx.set(ref,claimUpdate(run,row,destination,d.plan.request_digest),{merge:true});
      });
      if(agentContext) {
        if(this.publisher.beforeNotionStep) await this.publisher.beforeNotionStep(row,d.plan,null);
        const latest=(await ref.get()).data(),control=(await this.control.get()).data();
        this.publicationAgentGate(control,row,agentContext.request_digest,agentContext.action);
        if(latest.blob!==before.data().blob || attemptState(latest,row,destination).claimed!==d.plan.request_digest)
          refuse('publication_authority_or_plan_changed');
      }
      if(terminalRecovery) {
        const latest=(await ref.get()).data(),control=(await this.control.get()).data();
        this.terminalSheetsGate(control,row,terminalRecovery);
        if(latest.blob!==before.data().blob || attemptState(latest,row,destination).claimed!==d.plan.request_digest)
          refuse('publication_authority_or_plan_changed');
      }
      requirePublicationVerification(row,destination,this.clock());
      await this.publisher.write(row,destination,d.plan,{beforeWrite:async()=>{
        requirePublicationVerification(row,destination,this.clock());
        if(!terminalRecovery && !d.plan.hypothesis_keys?.length) return;
        const latest=(await ref.get()).data();this.hypothesisPlanGate(latest,row,d.plan);
        if(!terminalRecovery) return;
        const control=(await this.control.get()).data();
        this.terminalSheetsGate(control,row,terminalRecovery);
        if(latest.blob!==before.data().blob || attemptState(latest,row,destination).claimed!==d.plan.request_digest)
          refuse('publication_authority_or_plan_changed');
      }});
      return await this.publisher.reconcile(row,destination,d.plan);
    } catch(error) {
      if(error instanceof Refusal && /^(?:publication|workflow|firestore|research_tool|terminal_sheets_recovery)_[a-z_]+$/.test(error.message)) throw error;
      const wrapped=new Refusal(typeof error.message==='string' && /^publication_[a-z_]+$/.test(error.message) ? error.message : 'publication_attempt_unresolved');
      if(error.provider_feedback) wrapped.provider_feedback=error.provider_feedback;
      if(error.provider_response) wrapped.provider_response=error.provider_response;
      throw wrapped;
    }
  }
  // Why every hypothesis on this row stays out of a fresh plan, or null: an unbound outreach record
  // (an older bridge dropped its digest) or a verified-rows-only terminal Sheets recovery.
  async hypothesesWithheld(day,terminalRecovery=null,row=null) {
    if(terminalRecovery) return 'terminal_sheets_recovery_verified_rows_only';
    const run=(await this.db.doc(`${ROOT}/runs/${day}`).get()).data();
    return this.outreachUnbound(run,row || await this.get(day)) ? 'outreach_ready_unbound' : null;
  }
  outreachUnbound(run,row) {
    // Publication may resume directly after rollback, before put projects the sticky flag.
    return run?.outreach_ready_unbound===true || row?.outreach_ready!=null
      && run?.outreach_ready_digest!==valueHash(row.outreach_ready);
  }
  hypothesisPlanGate(run,row,plan) {
    if(this.outreachUnbound(run,row) && plan.hypothesis_keys?.length)
      refuse('publication_hypotheses_withheld');
  }
  async publishNotionBatch(row,plan,authority,collectionAuthority,proof,agentContext=null) {
    const ref=this.db.doc(`${ROOT}/runs/${row.date}`),before=await ref.get();
    const claims=attemptState(before.data(),row,'notion').batches || {},planDigest=valueHash(plan);
    if(Object.values(claims).some(claim=>claim.plan_digest!==planDigest || !same(claim.workflow_authority,authority)))
      refuse('publication_authority_or_plan_changed');
    const progress=await this.publisher.notionProgress(row,plan);
    if(progress.receipt) return progress.receipt;
    const step=progress.step;
    if(claims[step.number]) return null; // Unknown acknowledgment: observe this exact batch, never replay it.
    if(step.number>0 && (!claims[step.number-1] || claims[step.number-1].end!==step.start
        || step.number>1 && claims[step.number-1].page_id!==step.page_id))
      refuse('publication_notion_unclaimed_prefix');
    const claim={...step,plan_digest:planDigest,workflow_authority:authority};
    // The immutable plan already holds full request bytes. Store only exact bindings in the manifest.
    delete claim.body_json;
    await this.transaction(async tx=>{
      const control=(await tx.get(this.control)).data();this.fence(control);this.workflowGate(control,!!proof);
      if(!same(authority,control.workflow) || collectionAuthority && !same(collectionAuthority,control.workflow))
        refuse('publication_authority_changed');
      if(agentContext) this.publicationAgentGate(control,row,agentContext.request_digest,agentContext.action);
      requirePublicationVerification(row,'notion',this.clock());
      const snap=await tx.get(ref),run=snap.data();
      if(run.blob!==before.data().blob || attemptState(run,row,'notion').batches?.[step.number])
        refuse('publication_attempt_not_admitted');
      this.hypothesisPlanGate(run,row,plan);
      tx.set(ref,claimUpdate(run,row,'notion',plan.request_digest,{...claims,[step.number]:claim}),{merge:true});
    });
    // Reads and the claim can be slow. Check current authority and lease immediately before mutation.
    if(this.publisher.beforeNotionStep) await this.publisher.beforeNotionStep(row,plan,step);
    const latest=(await ref.get()).data(),control=(await this.control.get()).data();
    this.hypothesisPlanGate(latest,row,plan);
    this.fence(control);
    this.workflowGate(control,!!proof);
    if(agentContext) this.publicationAgentGate(control,row,agentContext.request_digest,agentContext.action);
    if(!same(authority,control.workflow) || latest.blob!==before.data().blob
        || !same(attemptState(latest,row,'notion').batches?.[step.number],claim)) refuse('publication_authority_or_plan_changed');
    requirePublicationVerification(row,'notion',this.clock());
    await this.publisher.writeNotionStep(row,plan,step);
    return await this.publisher.reconcile(row,'notion',plan);
  }
  async repairCheck(day, requestDigest, deadlineMS) {
    if (!dateOK(day) || !/^[a-f0-9]{64}$/.test(requestDigest)) refuse('validation_repair_request_invalid');
    const ref = this.db.doc(`${ROOT}/runs/${day}`);
    return this.transaction(async tx => {
      const control = (await tx.get(this.control)).data(); this.fence(control); this.workflowGate(control);
      const snap = await tx.get(ref), run = snap.data();
      if (!snap.exists || run.repair_request_digest!==requestDigest
          || !Number.isSafeInteger(run.repair_number) || run.repair_number<1
          || !Number.isSafeInteger(deadlineMS) || run.repair_deadline_ms!==deadlineMS
          || this.clock()>=deadlineMS || run.repair_claims?.[run.repair_number])
        refuse('validation_repair_input_not_admitted');
      this.budgetGate(control,run);
      tx.set(ref,{repair_claims:{...run.repair_claims,[run.repair_number]:requestDigest}},{merge:true});
      return true;
    });
  }
  // One authorized test reuses the Oct 1 session. It never enters daily runs or
  // workItems, and shares the existing lease and immutable blob implementation.
  adaptiveRef() {return this.db.doc(`${ROOT}/adaptiveTests/${ADAPTIVE_TEST}`);}
  async adaptiveOrigin() {
    const snap = await this.db.doc(`${ROOT}/runs/2026-10-01`).get();
    return {blob: snap.exists ? snap.data().blob : null, row: await this.get('2026-10-01')};
  }
  async adaptiveGet() {
    const snap = await this.adaptiveRef().get();
    return snap.exists ? JSON.parse(Buffer.from(await this.blobGet(snap.data().blob), 'base64').toString('utf8')) : null;
  }
  async adaptivePut(row) {
    const intent = row?.test_intent;
    if (row?.test_id !== ADAPTIVE_TEST || row.date !== '2026-10-01' || !intent
        || intent.test_id !== ADAPTIVE_TEST || intent.session_id !== row.session_id
        || intent.environment_id !== row.environment_id
        || !/^[a-f0-9]{64}$/.test(intent.intent_digest || '') || !/^[a-f0-9]{64}$/.test(row.daily_blob || ''))
      refuse('adaptive_test_binding_invalid');
    const hash = await this.blobPut(Buffer.from(JSON.stringify(row)).toString('base64'));
    const binding = sha(JSON.stringify([intent,row.session_id,row.environment_id,row.metadata,row.run_key,
      row.started_at,row.research_runtime_seconds,row.total_runtime_seconds,row.research_deadline_ms,row.daily_blob]));
    return this.transaction(async tx => {
      const control = (await tx.get(this.control)).data(); this.fence(control);
      const origin = await tx.get(this.db.doc(`${ROOT}/runs/2026-10-01`));
      const prior = await tx.get(this.adaptiveRef());
      if (!origin.exists || origin.data().blob !== row.daily_blob) refuse('adaptive_original_intent_changed');
      if (!prior.exists && row.state !== 'research_input_unresolved') refuse('adaptive_intent_not_staged');
      if (prior.exists && prior.data().binding !== binding) refuse('adaptive_intent_conflict');
      tx.set(this.adaptiveRef(), {blob: hash, intent_digest: intent.intent_digest, daily_blob: row.daily_blob,
        binding, state: row.state, claims: prior.exists ? prior.data().claims || {} : {},
        research_request_digest: intent.request_digest, research_deadline_ms: row.research_deadline_ms,
        qa_request_digest: row.qa?.request_digest || null, qa_deadline_ms: row.qa?.deadline_ms || null});
      return true;
    });
  }
  async adaptiveClaim(phase, requestDigest, deadlineMS) {
    if (!['research','qa'].includes(phase)) refuse('adaptive_phase_invalid');
    // Verify immutable intent bytes before claiming; the transaction pins the
    // same row blob, original daily blob, lease, deadline and one-use bit.
    const row = await this.adaptiveGet(), intent = row?.test_intent;
    if (!intent || intent.admission_blockers?.length !== 0 || intent.provider_calls !== 0
        || intent.profile?.enabled !== false || intent.profile?.publication_enabled !== false
        || intent.profile?.new_session_create_allowed !== false || intent.profile?.daily_state_reset_allowed !== false
        || intent.profile?.permanent_deletion_allowed !== false) refuse('adaptive_admission_incomplete');
    return this.transaction(async tx => {
      const control = (await tx.get(this.control)).data(); this.fence(control);
      const origin = await tx.get(this.db.doc(`${ROOT}/runs/2026-10-01`));
      const snap = await tx.get(this.adaptiveRef()), run = snap.data();
      if (control?.enabled !== true || !snap.exists || !origin.exists || origin.data().blob !== row.daily_blob
          || run.blob !== sha(Buffer.from(JSON.stringify(row))) || run.intent_digest !== intent.intent_digest
          || run[`${phase}_request_digest`] !== requestDigest
          || run[`${phase}_deadline_ms`] !== deadlineMS || run.claims?.[phase]
          || run.state !== (phase === 'research' ? 'research_input_unresolved' : 'awaiting_review')
          || !Number.isSafeInteger(deadlineMS) || this.clock() >= deadlineMS)
        refuse('adaptive_input_not_admitted');
      tx.set(this.adaptiveRef(), {claims: {...run.claims,[phase]: requestDigest}}, {merge: true});
      return true;
    });
  }
  async adaptiveFilePut(name, encoded) {
    if (!fileOK(name) || !name.startsWith('2026-10-01-') && name !== 'crm.json') refuse('adaptive_file_invalid');
    const hash = await this.blobPut(encoded), ref = this.db.doc(`${this.adaptiveRef().path}/files/${name}`);
    return this.transaction(async tx => {
      const control = (await tx.get(this.control)).data(); this.fence(control);
      const prior = await tx.get(ref);
      if ((name.endsWith('-artifact.json') || name.endsWith('-qa.json')) && prior.exists && prior.data().blob !== hash)
        refuse('artifact_identity_conflict');
      tx.set(ref,{blob: hash}); return true;
    });
  }
  async adaptiveFileGet(name) {
    if (!fileOK(name)) refuse('adaptive_file_invalid');
    const snap = await this.db.doc(`${this.adaptiveRef().path}/files/${name}`).get();
    if (!snap.exists) refuse('firestore_file_missing');
    return this.blobGet(snap.data().blob);
  }
  async dispatch(request) {
    if (this.terminalCollectionReceipt && !['acquire','renew','release','assert_lease','control','read_crm',
      'get','blob_receipt','rows','summary','work_item','active_qa','publish','refresh_crm','put',
      'file_put','file_get','snapshot'].includes(request.op)) refuse('terminal_qa_operation_forbidden');
    switch (request.op) {
      case 'init': {
        const value = request.value;
        if (value?.enabled !== false || value?.schema_version !== 'blueprint.research-control.v1') refuse('firestore_init_not_disabled');
        if (Object.hasOwn(value, 'paid_expansion')) refuse('paid_expansion_requires_direction_operation');
        if (Object.hasOwn(value, 'team_universe')) refuse('team_universe_requires_pin_operation');
        if (Object.hasOwn(value, 'site_universe')) refuse('site_universe_requires_pin_operation');
        if (Object.hasOwn(value, 'outreach_ready')) refuse('outreach_ready_requires_direction_operation');
        if (Object.hasOwn(value, 'screen_admission')) refuse('screen_admission_requires_pin_operation');
        return this.transaction(async tx => {
          const snap = await tx.get(this.control);
          if (snap.exists) refuse('firestore_control_already_exists');
          tx.set(this.control, value); return true;
        });
      }
      case 'runtime_set': {
        const {total_seconds:total,qa_seconds:qa,expected_config:expected,expected_source_commit:source}=request;
        if(!Number.isInteger(total) || total<120 || total>14400 || !Number.isInteger(qa) || qa<60 || qa>=total)
          refuse('runtime_phase_envelope_invalid');
        return this.transaction(async tx=>{
          const control=(await tx.get(this.control)).data();this.fence(control);
          if(control?.config?.discovery_profile!=='adaptive-sites-v1' || !hexOK(source,40)
              || source!==control.source_commit || valueHash(expected)!==valueHash(control.config))
            refuse('runtime_control_changed');
          const inventory=await tx.get(this.db.collection(`${ROOT}/runs`).limit(10001));
          if(inventory.docs.length>10000) refuse('firestore_history_limit');
          const active={qa_state:['qa_running','qa_input_unresolved','qa_correction_input_unresolved','qa_cancel_pending'],
            repair_state:['running','input_unresolved','cancel_pending'],
            publication_state:['running','input_unresolved','cancel_pending']};
          if(inventory.docs.some(doc=>{
            const row=doc.data();return !TERMINAL.includes(row.state)
              || Object.entries(active).some(([field,states])=>states.includes(row[field]));
          })) refuse('runtime_active_research_qa_repair_or_publication');
          const config={...control.config,max_runtime_seconds:total,qa_reserved_seconds:qa};
          tx.set(this.control,{config},{merge:true});
          return {previous_total_seconds:control.config.max_runtime_seconds,previous_qa_seconds:control.config.qa_reserved_seconds,
            total_seconds:total,qa_seconds:qa,source_commit:source,active_rows:0};
        });
      }
      case 'source_repin': {
        const {expected_source_commit:previous,new_source_commit:source}=request;
        if(!hexOK(previous,40) || !hexOK(source,40)) refuse('research_source_commit_invalid');
        return this.transaction(async tx=>{
          const control=(await tx.get(this.control)).data();await this.publicationFence(tx,control);
          if(control.source_commit!==previous) refuse('research_source_control_changed');
          const inventory=await tx.get(this.db.collection(`${ROOT}/runs`).limit(10001));
          if(inventory.docs.length>10000) refuse('firestore_history_limit');
          const active={qa_state:['qa_running','qa_input_unresolved','qa_correction_input_unresolved','qa_cancel_pending'],
            repair_state:['running','input_unresolved','cancel_pending'],
            publication_state:['running','input_unresolved','cancel_pending']};
          if(inventory.docs.some(doc=>{
            const row=doc.data();return !TERMINAL.includes(row.state)
              || Object.entries(active).some(([field,states])=>states.includes(row[field]));
          })) refuse('runtime_active_research_qa_repair_or_publication');
          // The containing release supplies the verified installed-package source.
          // Preserve every hold, grant, lease, historical row and cleanup liability.
          tx.set(this.control,{source_commit:source},{merge:true});
          return {previous_source_commit:previous,source_commit:source,active_rows:0};
        });
      }
      case 'configure': {
        const value = request.value;
        if (value?.schema_version !== 'blueprint.research-control.v1' || typeof value.enabled !== 'boolean')
          refuse('firestore_control_binding_invalid');
        return this.transaction(async tx => {
          const control = (await tx.get(this.control)).data(); this.fence(control);
          // Only paid_expansion_set, site_universe_set, outreach_ready_set and screen_admission_set write their owner sections;
          // a full replace keeps them.
          if (Object.hasOwn(value, 'paid_expansion') && valueHash(value.paid_expansion ?? null) !== valueHash(control.paid_expansion ?? null))
            refuse('paid_expansion_requires_direction_operation');
          if (Object.hasOwn(value, 'site_universe') && valueHash(value.site_universe ?? null) !== valueHash(control.site_universe ?? null))
            refuse('site_universe_requires_pin_operation');
          if (Object.hasOwn(value, 'outreach_ready') && valueHash(value.outreach_ready ?? null) !== valueHash(control.outreach_ready ?? null))
            refuse('outreach_ready_requires_direction_operation');
          if (Object.hasOwn(value, 'screen_admission') && valueHash(value.screen_admission ?? null) !== valueHash(control.screen_admission ?? null))
            refuse('screen_admission_requires_pin_operation');
          if (Object.hasOwn(value, 'team_universe') && valueHash(value.team_universe ?? null) !== valueHash(control.team_universe ?? null)) refuse('team_universe_requires_pin_operation');
          const replacement = {...value}; delete replacement.team_universe; delete replacement.paid_expansion; delete replacement.site_universe; delete replacement.outreach_ready;
          delete replacement.screen_admission;
          tx.set(this.control, {...replacement, cleanup_observation_required:control.cleanup_observation_required===true,
            lease: control.lease, ...(control.team_universe ? {team_universe: control.team_universe} : {}), ...(control.paid_expansion ? {paid_expansion: control.paid_expansion} : {}),
            ...(control.site_universe ? {site_universe: control.site_universe} : {}),
            ...(control.outreach_ready ? {outreach_ready: control.outreach_ready} : {}),
            ...(control.screen_admission ? {screen_admission: control.screen_admission} : {})}); return true;
        });
      }
      case 'acquire': return this.acquire(request.scope ?? null);
      case 'communications_lap_idle': return this.communicationsLapIdle();
      case 'renew': return this.renew();
      case 'release': return this.release();
      case 'assert_lease': return this.assertLease();
      case 'control': return (await this.control.get()).data() || null;
      case 'contact_research_context': return contactResearchContext(this,request.day);
      case 'contact_research_reconcile': {
        await this.assertLease();
        const row=await this.get(request.day);
        const manifest=(await this.db.doc(`${ROOT}/runs/${request.day}`).get()).data();
        return row ? finishContactResearchSafely(this,row,manifest.blob) : {state:'missing'};
      }
      case 'learning_context':
      {
        const control = (await this.control.get()).data();
        if (control?.learning?.enabled !== true) return null;
        await this.assertLease();
        if (typeof request.allow_create !== 'boolean') refuse('research_learning_create_direction_required');
        if (!this.learning) refuse('research_learning_binding_unavailable');
        try {return await this.learning(request, control.learning);}
        catch (error) {
          const code=error.message;
          refuse(/^(?:research_learning|business_daily|business_run|learning_consumer)_[a-z_]{1,75}$/.test(code)
            ? code : 'research_learning_unavailable');
        }
      }
      case 'history_search':
      case 'history_fetch': {
        await this.assertLease();
        const control=(await this.control.get()).data(),row=await this.get(request.day);
        if(control?.enabled!==true || control.learning?.enabled!==true || !this.learning
            || row?.history_profile!=='agent-history-v1'
            || control.config?.history_profile!=='agent-history-v1'
            || valueHash(row.history_binding)!==valueHash(control.learning))
          refuse('company_history_authority_changed');
        if(['binding','businessScope'].some(key=>{
          const expiry=Date.parse(control.learning[key]?.expiresAt);
          return !Number.isFinite(expiry) || expiry<=this.clock();
        })) refuse('company_history_scope_expired');
        try {return await this.learning(request,control.learning);}
        catch(error) {
          const code=error.message;
          return {ok:false,error:{code:/^(?:company_history|research_history)_[a-z_]{1,100}$/.test(code)
            ?code:'company_history_unavailable',guidance:'Correct the request or report the current company access/coverage gap.'}};
        }
      }
      case 'read_crm': {
        if (!this.crmReader) refuse('canonical_crm_read_unavailable');
        return this.crmReader();
      }
      case 'adaptive_origin': return this.adaptiveOrigin();
      case 'adaptive_get': return this.adaptiveGet();
      case 'adaptive_put': return this.adaptivePut(request.row);
      case 'adaptive_claim': return this.adaptiveClaim(request.phase,request.request_digest,request.deadline_ms);
      case 'adaptive_file_put': return this.adaptiveFilePut(request.name,request.bytes);
      case 'adaptive_file_get': return this.adaptiveFileGet(request.name);
      case 'get': return this.get(request.day);
      case 'blob_receipt': return this.blobReceipt(request.hash);
      case 'rows': return this.rows();
      case 'summary': return this.summary();
      case 'work_item': return this.workItem();
      case 'active_qa': return this.activeQA();
      case 'qa_check': return this.qaCheck(request.day,request.request_digest,request.deadline_ms);
      case 'qa_retry_check': return this.qaRetryCheck(request.day,request.request_digest,request.deadline_ms,request.number);
      case 'qa_correction_check': return this.qaCorrectionCheck(request.day,request.request_digest,request.deadline_ms,request.number);
      case 'repair_check': return this.repairCheck(request.day,request.request_digest,request.deadline_ms);
      case 'publish': return this.publish(request.day);
      case 'recover_terminal_sheets': return this.recoverTerminalSheets(request);
      case 'publication_input_check': return this.publicationInputCheck(request.day,request.request_digest,request.deadline_ms);
      case 'publication_agent_tool': return this.publicationAgentTool(request.day,request.action,request.request_digest);
      case 'refresh_crm': {
        await this.assertLease();
        if (!this.crmReader) refuse('canonical_crm_read_unavailable');
        const snapshot = await this.crmReader();
        await this.filePut('crm.json', Buffer.from(JSON.stringify(snapshot)).toString('base64'));
        return true;
      }
      case 'put': return this.put(request.row);
      case 'import_run': return this.importRun(request.row);
      case 'file_put': return this.filePut(request.name, request.bytes);
      case 'file_get': return this.fileGet(request.name);
      case 'snapshot': return this.snapshot(request.day);
      case 'cleanup_admit': return this.cleanupAdmit(request.day,request.policy);
      case 'cleanup_status': return this.cleanupStatus(request.day);
      case 'cleanup_archive': return this.cleanupArchive(request);
      case 'cleanup_archive_verify': return this.cleanupArchiveVerify(request.day,request.binding_digest);
      case 'cleanup_claim': return this.cleanupClaim(request.day,request.binding_digest);
      case 'cleanup_delete_check': return this.cleanupClaim(request.day,request.binding_digest,true);
      case 'create_check': return this.createCheck(request.day, request.metadata);
      case 'paid_expansion_set': {
        if (!Object.hasOwn(request, 'expected_sha256')) refuse('paid_expansion_request_invalid');
        return this.paidExpansionSet(request.expected_sha256, request.value);
      }
      case 'paid_expansion_audit': return this.paidExpansionAudit();
      case 'paid_expansion_object_put': return this.paidExpansionObjectPut(request.sha256, request.bytes);
      case 'paid_expansion_object_get': return this.paidExpansionObjectGet(request.sha256);
      case 'team_universe_snapshot': return this.teamUniverseSnapshot();
      case 'team_universe_idle': return this.teamUniverseIdle();
      case 'team_universe_object_get': return this.teamUniverseObjectGet(request.sha256,request.generation,request.size ?? null);
      case 'team_universe_object_put': return this.teamUniverseObjectPut(request.sha256,request.bytes);
      case 'team_universe_set': return this.teamUniverseSet(request.expected_sha256,request.value);
      case 'site_universe_object_get': return this.siteUniverseObjectGet(request.sha256,request.generation,request.size ?? null);
      case 'site_universe_object_put': return this.siteUniverseObjectPut(request.sha256,request.bytes);
      case 'site_universe_set': {
        if (!Object.hasOwn(request, 'expected_sha256')) refuse('site_universe_pin_invalid');
        return this.siteUniverseSet(request.expected_sha256, request.value);
      }
      case 'outreach_ready_object_get': return this.outreachReadyObjectGet(request.sha256,request.generation);
      case 'outreach_ready_object_put': return this.outreachReadyObjectPut(request.sha256,request.bytes);
      case 'outreach_ready_set': {
        if (!Object.hasOwn(request, 'expected_sha256')) refuse('outreach_ready_request_invalid');
        return this.outreachReadySet(request.expected_sha256, request.value);
      }
      case 'screen_admission_object_get': return this.screenAdmissionObjectGet(request.sha256,request.generation,request.size ?? null);
      case 'screen_admission_set': {
        if (!Object.hasOwn(request, 'expected_admission_id')) refuse('screen_admission_request_invalid');
        return this.screenAdmissionSet(request.expected_admission_id, request.value, request.supersede_uncertain ?? false);
      }
      case 'screen_admission_get': return this.screenAdmissionGet(request.admission_id);
      case 'screen_admission_history': return this.screenAdmissionHistory();
      case 'screen_admission_publish': return this.screenAdmissionPublish(request);
      case 'screen_snapshot': return this.screenSnapshot(request.admission_id);
      default: refuse('firestore_operation_invalid');
    }
  }
}

export async function readCanonicalCRM(account) {
  // The existing Firebase identity needs read access to this exact Sheet.
  // No Sheets writes, grant changes, or alternate credential are performed.
  const {JWT} = await import('google-auth-library');
  const auth = new JWT({email: account.client_email, key: account.private_key,
    scopes: ['https://www.googleapis.com/auth/spreadsheets.readonly']});
  const sheet = '1n95Ih0Swc-q-kZyUaDHoZh6SVzxvf_zt-CRR7i39bWY';
  try {
    const result = await auth.request({url: `https://sheets.googleapis.com/v4/spreadsheets/${sheet}/values/Prospects`,
      method: 'GET', timeout: 20000, retry: false});
    const snapshot = {sheet_id: sheet, complete: true, captured_at: new Date().toISOString(), values: result.data.values};
    if (!Array.isArray(snapshot.values) || Buffer.byteLength(JSON.stringify(snapshot)) > 2000000)
      refuse('canonical_crm_read_unavailable');
    return snapshot;
  } catch {refuse('canonical_crm_read_unavailable');}
}

// Heartbeats and pipe operations share a queue. Release disables the timer
// before it is queued, and drains any already queued renewal before returning.
export class LeaseChannel {
  constructor(store, {setIntervalImpl = setInterval, clearIntervalImpl = clearInterval} = {}) {
    this.store = store; this.tail = Promise.resolve(); this.heartbeat = null; this.lost = false;
    this.setInterval = setIntervalImpl; this.clearInterval = clearIntervalImpl;
  }
  enqueue(fn) {
    const result = this.tail.then(fn);
    this.tail = result.catch(() => {});
    return result;
  }
  call(request) {
    if (request.op === 'release') {this.clearInterval(this.heartbeat); this.heartbeat = null;}
    return this.enqueue(async () => {
      if (this.lost && !['release', 'acquire'].includes(request.op)) refuse('firestore_lease_lost');
      const value = await this.store.dispatch(request);
      if (request.op === 'acquire') {
        this.lost = false;
        this.heartbeat = this.setInterval(() => {
          void this.enqueue(() => this.store.renew()).catch(() => {this.lost = true;});
        }, 20000);
      }
      return value;
    });
  }
  async close() {
    this.clearInterval(this.heartbeat); this.heartbeat = null;
    await this.tail;
    await this.store.release();
  }
}

async function main() {
  const {initializeApp, cert} = await import('firebase-admin/app');
  const {getFirestore} = await import('firebase-admin/firestore');
  const account = JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT_JSON || '{}');
  if (account.project_id !== 'blueprint-8c1ca') refuse('firestore_project_binding_mismatch');
  const crmReader=()=>readCanonicalCRM(account);
  const publisher=await livePublisher(account,crmReader,process.env.NOTION_API_TOKEN || process.env.NOTION_API_KEY);
  const app = initializeApp({credential: cert(account)});
  const db = getFirestore(app);
  const {getStorage}=await import('firebase-admin/storage');
  // The trusted worker supplies a local compiled module, never a model URL.
  const learningPath = process.env.BLUEPRINT_DAILY_RESEARCH_LEARNING_MODULE;
  const learning = learningPath ? (await import(pathToFileURL(learningPath).href)).researchLearningHost(db) : null;
  const store = new Store(db, undefined, undefined,crmReader,publisher,learning,null,
    process.env.BLUEPRINT_DAILY_RESEARCH_WORKER_ENABLED==='false',getStorage(app).bucket(CLEANUP_BUCKET));
  const channel = new LeaseChannel(store);
  for await (const line of createInterface({input: process.stdin})) {
    try {
      if (line.length > 16 * 1024 * 1024) refuse('firestore_request_too_large');
      const request = JSON.parse(line);
      const value = await channel.call(request);
      process.stdout.write(JSON.stringify({ok: true, value}) + '\n');
    } catch (error) {
      process.stdout.write(JSON.stringify({ok: false, error: error instanceof Refusal ? error.message : 'firestore_request_unavailable'}) + '\n');
    }
  }
  await channel.close();
}
if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  main().catch(() => {process.stdout.write('{"ok":false,"error":"firestore_binding_unavailable"}\n'); process.exitCode = 1;});
}
